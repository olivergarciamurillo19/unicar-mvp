import type { User } from "@/types/unicar";

/**
 * Cancellation rate as percentage (0-100).
 * totalTrips = completed (numViajes) + cancelled (cancelaciones)
 */
export function getCancellationRate(user: User): number {
  const total = user.numViajes + user.cancelaciones;
  if (total === 0) return 0;
  return Math.round((user.cancelaciones / total) * 100);
}

/** Simple reliability label from cancellation rate: Alta / Media / Baja */
export function getReliabilityLabel(user: User): "Alta" | "Media" | "Baja" {
  const rate = getCancellationRate(user);
  if (rate <= 5) return "Alta";
  if (rate <= 15) return "Media";
  return "Baja";
}
