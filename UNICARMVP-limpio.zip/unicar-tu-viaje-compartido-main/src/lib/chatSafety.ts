/**
 * Chat safety helpers: redact contact info so it is never shown in chat screens.
 * Keeps communication inside UniCar and avoids leaking phone numbers.
 */

const PHONE_REDACT_PLACEHOLDER = "[número oculto por seguridad]";

/** Spanish mobile: 9 digits starting with 6/7/8/9 (optional spaces/dashes between groups) */
const PHONE_REGEX =
  /\b(6|7|8|9)\s*[\s\-.]?\s*\d{2}\s*[\s\-.]?\s*\d{2}\s*[\s\-.]?\s*\d{2}\s*[\s\-.]?\s*\d{2}\b/g;

/**
 * Redacts phone numbers from text so they are never displayed in chat.
 * Use when rendering message content or last-message previews in chat UI.
 */
export function redactPhoneNumbers(text: string): string {
  if (!text || typeof text !== "string") return text;
  return text.replace(PHONE_REGEX, PHONE_REDACT_PLACEHOLDER);
}
