/**
 * Demo-only auth: session stored in localStorage.
 * No Supabase Auth; replace with real auth when ready.
 *
 * Session persistence: survives page refresh and new tabs (same origin).
 * All reads/writes guard against SSR (typeof window === "undefined").
 */

const SESSION_KEY = "unicar_demo_session";
const ONBOARDING_SEEN_KEY = "unicar_onboarding_seen";

/** Only emails ending with this domain are allowed. */
export const ALLOWED_EMAIL_SUFFIX = "@inlumine.ual.es";

export function isAllowedEmail(email: string): boolean {
  const trimmed = email.trim().toLowerCase();
  return trimmed.endsWith(ALLOWED_EMAIL_SUFFIX) && trimmed.length > ALLOWED_EMAIL_SUFFIX.length;
}

export function getSession(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw && raw.trim() ? raw.trim() : null;
  } catch {
    return null;
  }
}

export function setSession(userId: string): void {
  if (typeof window === "undefined") return;
  const value = String(userId).trim();
  if (!value) return;
  try {
    localStorage.setItem(SESSION_KEY, value);
  } catch {
    // e.g. quota or private mode; ignore
  }
}

export function clearSession(): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(SESSION_KEY);
  } catch {
    // ignore
  }
}

export function isAuthenticated(): boolean {
  return getSession() != null;
}

export function hasSeenOnboarding(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return localStorage.getItem(ONBOARDING_SEEN_KEY) === "1";
  } catch {
    return false;
  }
}

export function setOnboardingSeen(): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(ONBOARDING_SEEN_KEY, "1");
  } catch {
    // ignore
  }
}
