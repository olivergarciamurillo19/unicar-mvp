import { useState } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import { isAuthenticated, setOnboardingSeen } from "@/lib/demoAuth";
import { motion, AnimatePresence } from "framer-motion";
import { Car, Leaf, Users, ArrowRight, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const slides = [
  {
    icon: Car,
    title: "Ahorra en gasolina, comparte el trayecto",
    subtitle: "Encuentra a quien hace tu misma ruta a la UAL y reparte gastos. Menos coste, misma llegada.",
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    icon: Leaf,
    title: "Menos coches, menos CO₂",
    subtitle: "Cada plaza compartida es un coche menos en la carretera. Tu huella baja; el campus también.",
    color: "text-success",
    bg: "bg-success/10",
  },
  {
    icon: Users,
    title: "Solo gente de la UAL, verificada",
    subtitle: "Todos entran con correo @inlumine.ual.es. Comunidad de confianza para ir y volver con seguridad.",
    color: "text-trust",
    bg: "bg-trust/10",
  },
];

const OnboardingPage = () => {
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  // Redirect unauthenticated users immediately (no flash of onboarding)
  if (!isAuthenticated()) {
    return <Navigate to="/auth" replace />;
  }

  const goHome = () => {
    setOnboardingSeen();
    navigate("/", { replace: true });
  };

  const next = () => {
    if (current < slides.length - 1) setCurrent(current + 1);
    else goHome();
  };

  const skip = () => goHome();

  return (
    <div className="flex min-h-screen flex-col bg-background px-6 pb-10 pt-16">
      <div className="flex justify-end">
        <button onClick={skip} className="text-sm font-medium text-muted-foreground">
          Omitir
        </button>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center text-center"
          >
            <div className={`mb-8 flex h-28 w-28 items-center justify-center rounded-3xl ${slides[current].bg}`}>
              {(() => {
                const Icon = slides[current].icon;
                return <Icon size={48} className={slides[current].color} strokeWidth={1.5} />;
              })()}
            </div>
            <h1 className="mb-4 text-2xl font-bold leading-tight text-foreground">
              {slides[current].title}
            </h1>
            <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
              {slides[current].subtitle}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex flex-col items-center gap-6">
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === current ? "w-8 bg-primary" : "w-2 bg-border"
              }`}
            />
          ))}
        </div>

        <Button
          onClick={next}
          className="h-14 w-full rounded-2xl bg-primary text-base font-semibold text-primary-foreground shadow-lg"
        >
          {current < slides.length - 1 ? (
            <>
              Siguiente <ChevronRight size={18} className="ml-1" />
            </>
          ) : (
            <>
              Empezar a usar UniCar <ArrowRight size={18} className="ml-1" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default OnboardingPage;
