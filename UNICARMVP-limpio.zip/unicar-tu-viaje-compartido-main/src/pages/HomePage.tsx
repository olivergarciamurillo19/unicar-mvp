import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, PlusCircle, Bell, Leaf, Shield, CheckCircle2, Car } from "lucide-react";
import { Button } from "@/components/ui/button";
import RideCard from "@/components/RideCard";
import BottomNav from "@/components/BottomNav";
import HomeMap from "@/components/HomeMap";
import EcoImpact from "@/components/EcoImpact";
import { useAppState } from "@/state/AppState";
import { toast } from "sonner";

const HomePage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, trips, tripRequests } = useAppState();
  const goToRide = (tripId: string) => navigate(`/ride/${tripId}`, { state: { from: location.pathname || "/" } });
  const activeTripsWithSeats = trips.filter((t) => t.estado === "activo" && t.plazasLibres > 0);

  // Dynamic home stats from in-memory state
  const today = new Date().toISOString().slice(0, 10);
  const viajesHoy = trips.filter((t) => t.fecha === today && t.estado !== "cancelado").length;
  const acceptedPassengers = tripRequests.filter((r) => r.estado === "aceptada").length;
  const driversInActiveRides = new Set(trips.filter((t) => t.estado === "activo").map((t) => t.conductorId)).size;
  const personasCompartiendo = acceptedPassengers + driversInActiveRides;
  const plazasLibres = trips.filter((t) => t.estado === "activo").reduce((sum, t) => sum + t.plazasLibres, 0);

  return (
    <div className="min-h-screen bg-background safe-bottom">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary via-primary to-accent/80 px-5 pb-6 pt-12">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-primary-foreground/70 font-medium">Hola,</p>
            <h1 className="text-xl font-bold text-primary-foreground">
              {currentUser.nombre.split(" ")[0]} 👋
            </h1>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              aria-label="Impacto ambiental"
              onClick={() => document.getElementById("eco-impact")?.scrollIntoView({ behavior: "smooth" })}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-foreground/15 backdrop-blur-sm transition-colors hover:bg-primary-foreground/25"
            >
              <Leaf size={20} className="text-primary-foreground" />
            </button>
            <button type="button" aria-label="Notificaciones" onClick={() => toast.info("Notificaciones — próximamente")} className="relative flex h-10 w-10 items-center justify-center rounded-full bg-primary-foreground/15 backdrop-blur-sm transition-colors hover:bg-primary-foreground/25">
              <Bell size={20} className="text-primary-foreground" />
              <span className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-destructive ring-2 ring-primary" />
            </button>
          </div>
        </div>

        {/* Interactive Map */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.4 }}
          className="mt-5 overflow-hidden rounded-2xl shadow-lg"
          style={{ height: 200 }}
        >
          <HomeMap />
        </motion.div>
      </div>

        {/* Quick actions — primary CTAs */}
      <div className="px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="-mt-5 flex gap-3"
        >
          <Button
            onClick={() => navigate("/search")}
            className="h-14 flex-1 gap-2.5 rounded-2xl border border-border bg-card text-foreground card-shadow hover:card-shadow-lg hover:bg-card hover:border-border font-semibold transition-all"
            variant="outline"
          >
            <Search size={20} className="text-primary shrink-0" />
            <span>Buscar plaza</span>
          </Button>
          <Button
            onClick={() => navigate("/create")}
            className="h-14 flex-1 gap-2.5 rounded-2xl shadow-lg shadow-primary/20 font-semibold transition-all"
          >
            <PlusCircle size={20} className="shrink-0" />
            <span>Ofrecer mi viaje</span>
          </Button>
        </motion.div>
        {/* Secondary: Mis viajes — easy to find from Home */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-3 flex justify-center"
        >
          <button
            type="button"
            onClick={() => navigate("/trips")}
            className="inline-flex items-center gap-2 rounded-xl border border-border/60 bg-card/80 px-4 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-muted/50 hover:border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
          >
            <Car size={18} className="text-primary shrink-0" />
            <span>Mis viajes</span>
            <span className="text-muted-foreground">→</span>
          </button>
        </motion.div>

        {/* Live stats bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.35 }}
          className="mt-5 flex justify-between rounded-2xl border border-border/50 bg-card p-4 card-shadow"
        >
          {[
            { label: "Viajes hoy", value: String(viajesHoy), pulse: true },
            { label: "Compartiendo", value: String(personasCompartiendo) },
            { label: "Plazas libres", value: String(plazasLibres) },
          ].map((stat, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="flex items-center gap-1">
                {stat.pulse && (
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
                  </span>
                )}
                <span className="text-lg font-bold text-foreground">{stat.value}</span>
              </div>
              <span className="text-[10px] text-muted-foreground">{stat.label}</span>
            </div>
          ))}
        </motion.div>

        {/* Safety & trust — reassuring copy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.38 }}
          className="mt-5 rounded-2xl border border-trust/25 bg-trust/5 p-4 card-shadow"
        >
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-trust/15">
              <Shield size={20} className="text-trust" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground">Viaja con confianza</h3>
              <p className="text-xs text-muted-foreground">Comunidad UAL verificada</p>
            </div>
          </div>
          <ul className="mt-3 space-y-2">
            {[
              "Solo estudiantes y personal de la UAL. Perfiles con verificación visible.",
              "Valoraciones y tasa de cancelación en cada conductor para que elijas con criterio.",
              "Si algo no va bien, puedes reportar desde el detalle del viaje. Revisamos cada incidencia.",
            ].map((text, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-trust" />
                <span>{text}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Environmental Impact */}
        <motion.div
          id="eco-impact"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="section-gap"
        >
          <EcoImpact />
        </motion.div>

        {/* Nearby rides */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          className="section-gap"
        >
          <div className="flex items-center justify-between gap-3">
            <h2 className="section-title-lg">Cerca de ti</h2>
            <button
              onClick={() => navigate("/search")}
              className="text-xs font-semibold text-primary shrink-0 hover:underline focus:outline-none focus:ring-0"
            >
              Ver todos →
            </button>
          </div>

          <div className="content-gap flex flex-col gap-3">
            {activeTripsWithSeats.length === 0 ? (
              <div className="empty-state rounded-2xl border border-dashed border-border bg-muted/30">
                <Search className="empty-state-icon size-10" />
                <p className="empty-state-title">Aún no hay viajes cercanos</p>
                <p className="empty-state-desc">
                  Busca por origen o publica tu propio viaje para compartir con la comunidad.
                </p>
                <div className="empty-state-cta flex gap-2">
                  <Button
                    onClick={() => navigate("/search")}
                    variant="outline"
                    className="rounded-xl border-border font-medium"
                  >
                    Buscar plaza
                  </Button>
                  <Button
                    onClick={() => navigate("/create")}
                    className="rounded-xl font-medium"
                  >
                    Ofrecer mi viaje
                  </Button>
                </div>
              </div>
            ) : (
              activeTripsWithSeats.slice(0, 3).map((trip, i) => (
                <motion.div
                  key={trip.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + i * 0.08 }}
                >
                  <RideCard
                    trip={trip}
                    onClick={() => goToRide(trip.id)}
                  />
                </motion.div>
              ))
            )}
          </div>
        </motion.div>

        {/* Recommended section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="section-gap"
        >
          <h2 className="section-title-lg">Rutas que encajan contigo</h2>
          <p className="section-subtitle">Según tu zona y horarios habituales</p>
          <div className="content-gap flex flex-col gap-3">
            {activeTripsWithSeats.length <= 3 ? (
              <div className="empty-state rounded-2xl border border-dashed border-border bg-muted/30 py-8">
                <Leaf className="empty-state-icon size-9" />
                <p className="empty-state-title">Más recomendaciones pronto</p>
                <p className="empty-state-desc">
                  Completa viajes y búsquedas para que podamos recomendarte trayectos ideales.
                </p>
              </div>
            ) : (
              activeTripsWithSeats.slice(3).map((trip, i) => (
                <motion.div
                  key={trip.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.85 + i * 0.08 }}
                >
                  <RideCard
                    trip={trip}
                    onClick={() => goToRide(trip.id)}
                  />
                </motion.div>
              ))
            )}
          </div>
        </motion.div>
      </div>

      <BottomNav />
    </div>
  );
};

export default HomePage;
