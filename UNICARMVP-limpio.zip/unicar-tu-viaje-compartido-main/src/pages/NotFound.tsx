import { Link } from "react-router-dom";

const NotFound = () => (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-muted px-5">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-bold">404</h1>
        <p className="mb-4 text-xl text-muted-foreground">Esta página no existe</p>
        <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
          <Link to="/" className="rounded-xl bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90">
            Volver al inicio
          </Link>
          <Link to="/search" className="rounded-xl border border-border bg-card px-5 py-2.5 text-sm font-medium text-foreground hover:bg-muted/50">
            Buscar plaza
          </Link>
        </div>
      </div>
    </div>
);

export default NotFound;
