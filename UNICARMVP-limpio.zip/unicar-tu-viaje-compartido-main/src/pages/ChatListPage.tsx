import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { VerificationBadge } from "@/components/VerificationBadge";
import { ChatTrustBanner } from "@/components/ChatTrustBanner";
import { useAppState } from "@/state/AppState";
import { redactPhoneNumbers } from "@/lib/chatSafety";

const ChatListPage = () => {
  const navigate = useNavigate();
  const { conversations } = useAppState();

  return (
    <div className="min-h-screen bg-background safe-bottom">
      <div className="px-5 pt-12">
        <h1 className="text-xl font-bold text-foreground">Mensajes</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Coordina punto de recogida y horario con conductores o pasajeros. Comunidad UAL verificada.
        </p>

        <div className="mt-4">
          <ChatTrustBanner />
        </div>

        <div className="mt-6 flex flex-col gap-2">
          {conversations.map((conv, i) => (
            <motion.div
              key={conv.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => navigate(`/chat/${conv.id}`)}
              className="flex cursor-pointer items-center gap-3 rounded-2xl bg-card p-4 card-shadow transition-shadow hover:card-shadow-lg"
            >
              <div className="relative shrink-0">
                <img
                  src={conv.usuario.avatar}
                  alt={conv.usuario.nombre}
                  className="h-12 w-12 rounded-full bg-secondary"
                />
                {conv.usuario.emailVerificado && (
                  <div className="absolute -bottom-0.5 -right-0.5">
                    <VerificationBadge verified={conv.usuario.emailVerificado} variant="compact" />
                  </div>
                )}
                {conv.noLeidos > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                    {conv.noLeidos}
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="truncate text-sm font-semibold text-foreground">
                    {conv.usuario.nombre}
                  </h3>
                  <span className="shrink-0 text-[10px] text-muted-foreground">
                    {new Date(conv.fecha).toLocaleTimeString("es-ES", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                <p className="mt-0.5 truncate text-xs text-muted-foreground">
                  {redactPhoneNumbers(conv.ultimoMensaje)}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {conversations.length === 0 && (
          <div className="empty-state rounded-2xl border border-dashed border-border bg-muted/30 mt-8">
            <MessageCircle className="empty-state-icon size-10" />
            <p className="empty-state-title">Aún no tienes conversaciones</p>
            <p className="empty-state-desc">
              Solicita una plaza en un viaje desde Buscar plaza y podrás hablar con el conductor aquí.
            </p>
            <div className="empty-state-cta flex flex-wrap gap-2 justify-center mt-4">
              <Button onClick={() => navigate("/search")} variant="outline" className="rounded-xl border-border font-medium">
                Buscar plaza
              </Button>
              <Button onClick={() => navigate("/home")} className="rounded-xl font-medium">
                Volver al inicio
              </Button>
            </div>
          </div>
        )}
      </div>
      <BottomNav />
    </div>
  );
};

export default ChatListPage;
