import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, SlidersHorizontal, MapPin } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import RideCard from "@/components/RideCard";
import BottomNav from "@/components/BottomNav";
import { useAppState } from "@/state/AppState";

const origenes = ["Todos", "Roquetas", "Aguadulce", "El Ejido", "Almería", "Vícar", "Huércal"];

const SearchPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { trips } = useAppState();
  const goToRide = (tripId: string) => navigate(`/ride/${tripId}`, { state: { from: location.pathname } });
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrigen, setSelectedOrigen] = useState("Todos");

  const filtered = trips.filter((t) => {
    if (t.estado !== "activo" || t.plazasLibres < 1) return false;
    const matchSearch =
      !searchQuery ||
      t.origen.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.conductor.nombre.toLowerCase().includes(searchQuery.toLowerCase());
    const matchOrigen =
      selectedOrigen === "Todos" ||
      t.origen.toLowerCase().includes(selectedOrigen.toLowerCase());
    return matchSearch && matchOrigen;
  });

  return (
    <div className="min-h-screen bg-background safe-bottom">
      <div className="px-5 pt-12">
        <h1 className="text-xl font-bold text-foreground">Buscar plaza</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Encuentra quien comparte ruta contigo hacia la UAL
        </p>

        {/* Search bar */}
        <div className="mt-5 flex gap-2">
          <div className="relative flex-1">
            <Search
              size={18}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
            />
            <Input
              placeholder="Origen, conductor..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-12 rounded-xl border border-border bg-card pl-11 text-sm focus-visible:ring-2"
            />
          </div>
          <button
            type="button"
            onClick={() => toast.info("Filtros avanzados próximamente")}
            aria-label="Filtros"
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-border bg-card transition-colors hover:bg-muted/50"
          >
            <SlidersHorizontal size={18} className="text-muted-foreground" />
          </button>
        </div>

        {/* Origin pills */}
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {origenes.map((o) => (
            <button
              key={o}
              type="button"
              onClick={() => setSelectedOrigen(o)}
              className={`shrink-0 rounded-full px-4 py-2.5 text-xs font-medium transition-all ${
                selectedOrigen === o
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-card text-muted-foreground border border-border card-shadow hover:border-border"
              }`}
            >
              {o}
            </button>
          ))}
        </div>

        {/* Results */}
        <div className="section-gap">
          <h2 className="section-title-lg">Viajes disponibles</h2>
          <p className="section-subtitle">
            {filtered.length} viaje{filtered.length !== 1 ? "s" : ""} con plaza{filtered.length !== 1 ? "s" : ""}
          </p>
          <div className="content-gap flex flex-col gap-3">
            {filtered.map((trip, i) => (
              <motion.div
                key={trip.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <RideCard
                  trip={trip}
                  onClick={() => goToRide(trip.id)}
                />
              </motion.div>
            ))}
          </div>

          {filtered.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="empty-state rounded-2xl border border-dashed border-border bg-muted/30 mt-6"
            >
              <MapPin className="empty-state-icon size-10" />
              <p className="empty-state-title">Ningún viaje con plaza ahora</p>
              <p className="empty-state-desc">
                Cambia el origen o sé el primero en ofrecer tu ruta.
              </p>
              <div className="empty-state-cta flex gap-2">
                <Button
                  onClick={() => navigate("/create")}
                  className="rounded-xl font-medium"
                >
                  Ofrecer mi viaje
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
      <BottomNav />
    </div>
  );
};

export default SearchPage;
