import { useState } from "react";
import { useNavigate, Navigate, useLocation } from "react-router-dom";
import { setSession, isAuthenticated, isAllowedEmail, hasSeenOnboarding } from "@/lib/demoAuth";
import { motion } from "framer-motion";
import { Car, Mail, Lock, User, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const MIN_PASSWORD_LENGTH = 6;
const MIN_NOMBRE_LENGTH = 2;

/** Basic email format: something@domain (used before UAL check). */
function looksLikeEmail(value: string): boolean {
  const trimmed = value.trim();
  return trimmed.length >= 3 && trimmed.includes("@") && trimmed.indexOf("@") > 0 && trimmed.indexOf("@") < trimmed.length - 1;
}

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [contrasena, setContrasena] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from;
  const isValidReturnPath = from && /^\/(home|search|create|trips|profile|chat|ride)(\/|$)/.test(from);
  const emailTrimmedForDisplay = correo.trim().toLowerCase();
  const showEmailDomainError =
    emailTrimmedForDisplay.length > 0 &&
    looksLikeEmail(correo) &&
    !isAllowedEmail(correo);

  // If already logged in, redirect immediately (no flash of login form)
  if (isAuthenticated()) {
    return <Navigate to="/home" replace />;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    const emailTrimmed = correo.trim().toLowerCase();
    const passwordTrimmed = contrasena.trim();
    const nameTrimmed = nombre.trim();

    if (!emailTrimmed) {
      toast.error("Introduce tu correo electrónico");
      return;
    }
    if (!passwordTrimmed) {
      toast.error("Introduce tu contraseña");
      return;
    }
    if (passwordTrimmed.length < MIN_PASSWORD_LENGTH) {
      toast.error(`La contraseña debe tener al menos ${MIN_PASSWORD_LENGTH} caracteres`);
      return;
    }
    if (!isLogin && !nameTrimmed) {
      toast.error("Introduce tu nombre completo");
      return;
    }
    if (!isLogin && nameTrimmed.length < MIN_NOMBRE_LENGTH) {
      toast.error("El nombre debe tener al menos 2 caracteres");
      return;
    }
    if (!looksLikeEmail(correo)) {
      toast.error("El correo no tiene un formato válido (debe contener @ y dominio)");
      return;
    }
    if (!isAllowedEmail(emailTrimmed)) {
      toast.error(
        isLogin
          ? "Solo puedes entrar con tu correo @inlumine.ual.es de la universidad"
          : "Usa tu correo @inlumine.ual.es para unirte a la comunidad universitaria"
      );
      return;
    }

    setIsSubmitting(true);
    try {
      setSession("u0"); // demo user id
      toast.success(isLogin ? "¡Bienvenido de nuevo!" : "¡Listo! Ya puedes buscar o ofrecer viajes.");
      const nextPath = isValidReturnPath ? from : hasSeenOnboarding() ? "/home" : "/onboarding";
      navigate(nextPath, { replace: true });
    } catch (err) {
      toast.error("Ha ocurrido un error. Inténtalo de nuevo.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1 flex-col justify-between px-6 pb-8 pt-16">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center"
        >
          <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary">
            <Car size={32} className="text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">UniCar</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Ahorra, comparte y reduce tu huella. Solo comunidad UAL.
          </p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          onSubmit={handleSubmit}
          className="mt-10 flex flex-col gap-4"
        >
          <h2 className="text-center text-xl font-semibold text-foreground">
            {isLogin ? "Inicia sesión" : "Crea tu cuenta"}
          </h2>
          <p className="text-center text-sm text-muted-foreground">
            {isLogin
              ? "Solo correo @inlumine.ual.es — comunidad verificada"
              : "Tu correo @inlumine.ual.es nos asegura que viajas con compañeros de la UAL"}
          </p>

          {!isLogin && (
            <div className="relative">
              <User size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Nombre completo"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                className="h-12 rounded-xl border-border bg-card pl-11 text-sm"
              />
            </div>
          )}

          <div className="relative">
            <Mail size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="email"
              placeholder="tu.nombre@inlumine.ual.es"
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
              className={`h-12 rounded-xl border-border bg-card pl-11 text-sm ${showEmailDomainError ? "border-destructive" : ""}`}
              aria-invalid={showEmailDomainError}
            />
            {showEmailDomainError && (
              <p className="mt-1.5 text-xs text-destructive">
                Usa tu correo @inlumine.ual.es de la UAL para continuar.
              </p>
            )}
          </div>

          <div className="relative">
            <Lock size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              type={showPassword ? "text" : "password"}
              placeholder="Contraseña"
              value={contrasena}
              onChange={(e) => setContrasena(e.target.value)}
              className="h-12 rounded-xl border-border bg-card pl-11 pr-11 text-sm"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          {isLogin && (
            <button
              type="button"
              onClick={() => toast.info("Próximamente. Contacta con soporte @ual.es")}
              className="self-end text-xs font-medium text-primary"
            >
              ¿Olvidaste tu contraseña?
            </button>
          )}

          <Button
            type="submit"
            disabled={isSubmitting}
            className="mt-2 h-14 w-full rounded-2xl bg-primary text-base font-semibold text-primary-foreground shadow-lg"
          >
            {isSubmitting ? "Espera..." : isLogin ? "Entrar" : "Crear cuenta"}
          </Button>
        </motion.form>

        <div className="mt-8 text-center">
          <span className="text-sm text-muted-foreground">
            {isLogin ? "¿No tienes cuenta? " : "¿Ya tienes cuenta? "}
          </span>
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm font-semibold text-primary"
          >
            {isLogin ? "Regístrate" : "Inicia sesión"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
