import { useNavigate } from "react-router-dom";
import { clearSession } from "@/lib/demoAuth";
import { motion } from "framer-motion";
import {
  Star, Shield, Car, Clock, XCircle, ThumbsUp, LogOut,
  ChevronRight, Settings, HelpCircle, Flag, Leaf, ShieldCheck, CheckCircle2
} from "lucide-react";
import BottomNav from "@/components/BottomNav";
import { useAppState } from "@/state/AppState";
import { toast } from "sonner";
import { VerificationBadge } from "@/components/VerificationBadge";
import { getCancellationRate, getReliabilityLabel } from "@/lib/trustUtils";
import { getAverageRating, getRatingCount } from "@/data/ratingsStore";

const ProfilePage = () => {
  const navigate = useNavigate();
  const { currentUser } = useAppState();
  const reliabilityLabel = getReliabilityLabel(currentUser);
  const avgFromRatings = getAverageRating(currentUser.id);
  const countFromRatings = getRatingCount(currentUser.id);
  const displayRating = avgFromRatings ?? currentUser.rating;
  const displayCount = countFromRatings > 0 ? countFromRatings : currentUser.valoraciones;

  const menuItems = [
    { icon: Car, label: "Mis viajes", action: () => navigate("/trips") },
    { icon: Star, label: "Mis valoraciones", action: () => toast("Próximamente") },
    { icon: Shield, label: "Seguridad y confianza", action: () => document.getElementById("seguridad-confianza")?.scrollIntoView({ behavior: "smooth" }) },
    { icon: Flag, label: "Centro de reportes", action: () => toast("Próximamente") },
    { icon: Leaf, label: "Mi impacto ambiental", action: () => toast("Próximamente") },
    { icon: Settings, label: "Configuración", action: () => toast("Próximamente") },
    { icon: HelpCircle, label: "Ayuda y soporte", action: () => toast("Próximamente") },
  ];

  return (
    <div className="min-h-screen bg-background safe-bottom">
      <div className="px-5 pt-12">
        {/* Profile header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center"
        >
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.nombre}
              className="h-20 w-20 rounded-full bg-secondary ring-4 ring-card"
            />
            {currentUser.emailVerificado && (
              <div className="absolute -bottom-0.5 -right-0.5">
                <VerificationBadge verified={currentUser.emailVerificado} variant="compact" />
              </div>
            )}
          </div>
          <h1 className="mt-3 text-xl font-bold text-foreground">{currentUser.nombre}</h1>
          <p className="text-sm text-muted-foreground">
            {currentUser.carrera} · {currentUser.curso}
          </p>
          <div className="mt-2">
            <VerificationBadge verified={currentUser.emailVerificado} variant="inline" />
          </div>

          {/* Valoración media (desde capa de valoraciones o perfil) */}
          <div className="mt-4 flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star
                key={s}
                size={18}
                className={s <= Math.round(displayRating) ? "text-warning" : "text-border"}
                fill={s <= Math.round(displayRating) ? "hsl(var(--warning))" : "none"}
              />
            ))}
            <span className="ml-1 text-sm font-bold text-foreground">{displayRating}</span>
            <span className="ml-1 text-xs text-muted-foreground">({displayCount} valoraciones)</span>
          </div>
        </motion.div>

        {/* Trust indicators — stats including cancellation rate */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="mt-5 rounded-2xl bg-card p-4 card-shadow"
        >
          <h3 className="section-title mb-3 flex items-center gap-2">
            <ShieldCheck size={16} className="text-trust shrink-0" />
            Tu historial de confianza
          </h3>
          <div className="flex flex-wrap gap-3">
            {[
              { icon: Car, label: "Viajes", value: String(currentUser.numViajes) },
              { icon: XCircle, label: "Cancelaciones", value: String(currentUser.cancelaciones) },
              { icon: Clock, label: "Puntualidad", value: `${currentUser.puntualidad}%` },
              { icon: ShieldCheck, label: "Fiabilidad", value: reliabilityLabel },
              { icon: ThumbsUp, label: "Valoraciones", value: String(displayCount) },
            ].map((stat) => (
              <div key={stat.label} className="flex flex-1 flex-col items-center rounded-xl bg-secondary/60 p-2.5">
                <stat.icon size={16} className="mb-0.5 text-primary" />
                <span className="text-sm font-bold text-foreground">{stat.value}</span>
                <span className="text-[9px] text-muted-foreground text-center leading-tight">{stat.label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Mis viajes — prominent shortcut so users don't get lost */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-5"
        >
          <button
            type="button"
            onClick={() => navigate("/trips")}
            className="flex w-full items-center gap-3 rounded-2xl border-2 border-primary/30 bg-primary/10 px-4 py-3.5 text-left transition-colors hover:bg-primary/15 hover:border-primary/50 focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/20">
              <Car size={20} className="text-primary" />
            </div>
            <div className="flex-1 text-left">
              <span className="block text-sm font-bold text-foreground">Mis viajes</span>
              <span className="block text-xs text-muted-foreground">Próximos, pasados y solicitudes</span>
            </div>
            <ChevronRight size={20} className="text-primary shrink-0" />
          </button>
        </motion.div>

        {/* Menu */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6 rounded-2xl bg-card card-shadow"
        >
          {menuItems.map((item, i) => (
            <button
              key={item.label}
              onClick={item.action}
              className={`flex w-full items-center gap-3 px-4 py-3.5 text-left ${
                i !== menuItems.length - 1 ? "border-b border-border" : ""
              }`}
            >
              <item.icon size={18} className="text-muted-foreground" />
              <span className="flex-1 text-sm font-medium text-foreground">{item.label}</span>
              <ChevronRight size={16} className="text-muted-foreground/50" />
            </button>
          ))}
        </motion.div>

        {/* Safety & trust section — same copy as Home for product consistency */}
        <motion.div
          id="seguridad-confianza"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mt-6 rounded-2xl border border-trust/25 bg-trust/5 p-4 card-shadow"
        >
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-trust/15">
              <Shield size={20} className="text-trust" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground">Viaja con confianza</h3>
              <p className="text-xs text-muted-foreground">Comunidad UAL verificada</p>
            </div>
          </div>
          <ul className="mt-3 space-y-2">
            {[
              "Solo estudiantes y personal de la UAL. Perfiles con verificación visible.",
              "Valoraciones y tasa de cancelación en cada conductor para que elijas con criterio.",
              "Si algo no va bien, puedes reportar desde el detalle del viaje. Revisamos cada incidencia.",
            ].map((text, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                <CheckCircle2 size={14} className="mt-0.5 shrink-0 text-trust" />
                <span>{text}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Logout */}
        <button
          onClick={() => {
            clearSession();
            toast.success("Sesión cerrada");
            navigate("/auth", { replace: true });
          }}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-card py-3.5 card-shadow"
        >
          <LogOut size={18} className="text-destructive" />
          <span className="text-sm font-medium text-destructive">Cerrar sesión</span>
        </button>
      </div>
      <BottomNav />
    </div>
  );
};

export default ProfilePage;
