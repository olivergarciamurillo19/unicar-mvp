import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { MapPin, Clock, Users, CalendarDays, StickyNote, ChevronLeft, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAppState } from "@/state/AppState";
import type { Trip } from "@/types/unicar";

const UAL_DESTINO = "Universidad de Almería (UAL)";

function nextDayISO(): string {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

const diasSemana = [
  { key: "L", label: "Lu" },
  { key: "M", label: "Ma" },
  { key: "X", label: "Mi" },
  { key: "J", label: "Ju" },
  { key: "V", label: "Vi" },
];

const MAX_NOTAS_LENGTH = 500;

const CreateRidePage = () => {
  const navigate = useNavigate();
  const { currentUser, addTrip } = useAppState();
  const [step, setStep] = useState(0);
  const [origen, setOrigen] = useState("");
  const [horaSalida, setHoraSalida] = useState("08:00");
  const [plazas, setPlazas] = useState(3);
  const [recurrente, setRecurrente] = useState(false);
  const [diasSeleccionados, setDiasSeleccionados] = useState<string[]>([]);
  const [notas, setNotas] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleDia = (d: string) => {
    setDiasSeleccionados((prev) =>
      prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]
    );
  };

  const handlePublish = () => {
    if (isSubmitting) return;
    if (!origen.trim()) {
      toast.error("Indica el origen del viaje");
      return;
    }
    if (recurrente && diasSeleccionados.length === 0) {
      toast.error("Selecciona al menos un día para viajes recurrentes");
      return;
    }
    const notasTrimmed = notas.trim();
    if (notasTrimmed.length > MAX_NOTAS_LENGTH) {
      toast.error(`Las notas no pueden superar ${MAX_NOTAS_LENGTH} caracteres`);
      return;
    }
    setIsSubmitting(true);
    try {
      const fecha = nextDayISO();
      const newTrip: Trip = {
        id: `t-new-${Date.now()}`,
        conductorId: currentUser.id,
        conductor: currentUser,
        origen: origen.trim(),
        destino: UAL_DESTINO,
        horaSalida,
        fecha,
        plazasTotal: plazas,
        plazasLibres: plazas,
        recurrente,
        diasRecurrencia: recurrente && diasSeleccionados.length > 0 ? diasSeleccionados : undefined,
        notas: notasTrimmed || undefined,
        estado: "activo",
      };
      // Persist to shared state; ride appears in Home, Search, and My Trips (Próximos viajes)
      addTrip(newTrip);
      toast.success("Viaje publicado. Quien busque plaza lo verá.");
      navigate("/home", { replace: true });
    } catch (err) {
      toast.error("No se pudo publicar el viaje. Inténtalo de nuevo.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const steps = [
    // Step 0: Origin
    <motion.div key="s0" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
      <h2 className="section-title-lg">¿Desde dónde sales?</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Destino: Universidad de Almería (UAL)
      </p>
      <div className="relative mt-6">
        <MapPin size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-primary" />
        <Input
          placeholder="Ej: Roquetas de Mar, Aguadulce..."
          value={origen}
          onChange={(e) => setOrigen(e.target.value)}
          className="h-14 rounded-2xl border-border bg-card pl-11 text-sm"
        />
      </div>
      <div className="mt-4 rounded-2xl bg-card p-4 card-shadow">
        <p className="text-xs font-medium text-muted-foreground">Destino</p>
        <div className="mt-1 flex items-center gap-2">
          <MapPin size={16} className="text-accent" />
          <span className="text-sm font-semibold text-foreground">Universidad de Almería (UAL)</span>
        </div>
      </div>
      {/* Quick picks */}
      <div className="mt-4 flex flex-wrap gap-2">
        {["Roquetas de Mar", "Aguadulce", "El Ejido", "Almería Centro", "Vícar", "Huércal de Almería"].map((loc) => (
          <button
            key={loc}
            onClick={() => setOrigen(loc)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
              origen === loc
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground"
            }`}
          >
            {loc}
          </button>
        ))}
      </div>
    </motion.div>,

    // Step 1: Time & Seats
    <motion.div key="s1" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
      <h2 className="section-title-lg">Hora y plazas</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Cuántas plazas ofreces y a qué hora sales
      </p>

      <div className="mt-6">
        <label className="flex items-center gap-2 text-sm font-medium text-foreground">
          <Clock size={16} className="text-primary" /> Hora de salida
        </label>
        <Input
          type="time"
          value={horaSalida}
          onChange={(e) => setHoraSalida(e.target.value)}
          className="mt-2 h-14 rounded-2xl border-border bg-card text-center text-lg font-semibold"
        />
      </div>

      <div className="mt-6">
        <label className="flex items-center gap-2 text-sm font-medium text-foreground">
          <Users size={16} className="text-primary" /> Plazas disponibles
        </label>
        <div className="mt-3 flex items-center justify-center gap-4">
          {[1, 2, 3, 4].map((n) => (
            <button
              key={n}
              onClick={() => setPlazas(n)}
              className={`flex h-14 w-14 items-center justify-center rounded-2xl text-lg font-bold transition-all ${
                plazas === n
                  ? "bg-primary text-primary-foreground scale-110 shadow-lg"
                  : "bg-card text-foreground card-shadow"
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </div>
    </motion.div>,

    // Step 2: Recurring & Notes
    <motion.div key="s2" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }}>
      <h2 className="section-title-lg">¿Viaje puntual o recurrente?</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Si vas los mismos días, marca recurrente y ahorra publicando una sola vez
      </p>

      <div className="mt-6 flex gap-3">
        <button
          onClick={() => setRecurrente(false)}
          className={`flex-1 rounded-2xl p-4 text-center transition-all ${
            !recurrente ? "bg-primary text-primary-foreground shadow-lg" : "bg-card text-foreground card-shadow"
          }`}
        >
          <CalendarDays size={24} className="mx-auto mb-2" />
          <span className="text-sm font-semibold">Puntual</span>
        </button>
        <button
          onClick={() => setRecurrente(true)}
          className={`flex-1 rounded-2xl p-4 text-center transition-all ${
            recurrente ? "bg-primary text-primary-foreground shadow-lg" : "bg-card text-foreground card-shadow"
          }`}
        >
          <CalendarDays size={24} className="mx-auto mb-2" />
          <span className="text-sm font-semibold">Recurrente</span>
        </button>
      </div>

      {recurrente && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="mt-4"
        >
          <p className="mb-2 text-sm font-medium text-foreground">Días de repetición</p>
          <div className="flex justify-between gap-2">
            {diasSemana.map((d) => (
              <button
                key={d.key}
                onClick={() => toggleDia(d.key)}
                className={`flex h-12 w-12 items-center justify-center rounded-xl text-sm font-semibold transition-all ${
                  diasSeleccionados.includes(d.key)
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-muted-foreground card-shadow"
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </motion.div>
      )}

      <div className="mt-6">
        <label className="flex items-center gap-2 text-sm font-medium text-foreground">
          <StickyNote size={16} className="text-primary" /> Notas opcionales
        </label>
        <textarea
          placeholder="Ej: Parada en el centro comercial, solo equipaje de mano..."
          value={notas}
          onChange={(e) => setNotas(e.target.value)}
          maxLength={MAX_NOTAS_LENGTH}
          className="mt-2 h-24 w-full resize-none rounded-2xl border border-border bg-card p-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
        {notas.length > MAX_NOTAS_LENGTH * 0.9 && (
          <p className="mt-1 text-xs text-muted-foreground">{notas.length}/{MAX_NOTAS_LENGTH} caracteres</p>
        )}
      </div>
    </motion.div>,
  ];

  return (
    <div className="min-h-screen bg-background px-5 pb-10 pt-12">
      <div className="flex items-center gap-3">
        <button
          onClick={() => (step > 0 ? setStep(step - 1) : navigate("/home", { replace: true }))}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-card card-shadow"
        >
          <ChevronLeft size={20} className="text-foreground" />
        </button>
        <div>
          <h1 className="section-title-lg">Ofrecer mi viaje</h1>
          <p className="text-xs text-muted-foreground">
            Paso {step + 1} de {steps.length}
          </p>
        </div>
      </div>

      {/* Progress bar */}
      <div className="mt-5 flex gap-2">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`h-1 flex-1 rounded-full transition-colors ${
              i <= step ? "bg-primary" : "bg-border"
            }`}
          />
        ))}
      </div>

      <div className="mt-8">{steps[step]}</div>

      <div className="mt-8">
        {step < steps.length - 1 ? (
          <Button
            onClick={() => {
              if (step === 0 && !origen.trim()) {
                toast.error("Indica el origen del viaje");
                return;
              }
              setStep(step + 1);
            }}
            className="h-14 w-full rounded-2xl bg-primary text-base font-semibold text-primary-foreground shadow-lg"
          >
            Siguiente
          </Button>
        ) : (
          <Button
            onClick={handlePublish}
            disabled={isSubmitting}
            className="h-14 w-full gap-2 rounded-2xl bg-primary text-base font-semibold text-primary-foreground shadow-lg"
          >
            {isSubmitting ? (
              "Publicando..."
            ) : (
              <>
                <Check size={20} />
                Publicar y ofrecer plazas
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
};

export default CreateRidePage;
