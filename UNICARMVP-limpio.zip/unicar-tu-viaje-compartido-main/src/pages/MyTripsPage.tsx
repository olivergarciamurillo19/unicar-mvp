import { useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ChevronRight,
  Clock,
  MapPin,
  CheckCircle2,
  XCircle,
  Hourglass,
  Send,
  Inbox,
  Calendar,
  Car,
  MessageCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";
import { useAppState } from "@/state/AppState";
import type { Trip, TripRequest } from "@/types/unicar";

function getTodayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

function isUpcoming(fecha: string, today: string) {
  return fecha >= today;
}

function RequestStatusBadge({ estado }: { estado: TripRequest["estado"] }) {
  switch (estado) {
    case "aceptada":
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-2.5 py-0.5 text-[11px] font-medium text-primary">
          <CheckCircle2 size={12} /> Aceptada
        </span>
      );
    case "pendiente":
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-warning/15 px-2.5 py-0.5 text-[11px] font-medium text-warning">
          <Hourglass size={12} /> Pendiente
        </span>
      );
    case "rechazada":
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-destructive/15 px-2.5 py-0.5 text-[11px] font-medium text-destructive">
          <XCircle size={12} /> Rechazada
        </span>
      );
  }
}

const MyTripsPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { trips, tripRequests, currentUser, conversations, updateTripRequestStatus } = useAppState();
  const today = getTodayISO();
  const goToRide = (tripId: string) => {
    if (tripId) navigate(`/ride/${tripId}`, { state: { from: location.pathname } });
  };
  const totalUnread = conversations.reduce((acc, c) => acc + c.noLeidos, 0);

  const {
    proximosViajes,
    viajesPasados,
    solicitudesEnviadas,
    solicitudesRecibidas,
  } = useMemo(() => {
    // Grouping: trips where user is driver OR has accepted request; requests sent by user; requests for user's trips.
    const acceptedTripIds = new Set(
      tripRequests
        .filter(
          (r) => r.pasajeroId === currentUser.id && r.estado === "aceptada"
        )
        .map((r) => r.viajeId)
    );

    const isMyTrip = (trip: Trip) =>
      trip.conductorId === currentUser.id || acceptedTripIds.has(trip.id);

    const allMyTrips = trips.filter((t) => isMyTrip(t) && t.estado !== "cancelado");
    const proximosViajes = allMyTrips
      .filter((t) => isUpcoming(t.fecha, today))
      .sort(
        (a, b) =>
          a.fecha.localeCompare(b.fecha) ||
          a.horaSalida.localeCompare(b.horaSalida) ||
          a.id.localeCompare(b.id)
      );
    const viajesPasados = allMyTrips
      .filter((t) => !isUpcoming(t.fecha, today))
      .sort(
        (a, b) =>
          b.fecha.localeCompare(a.fecha) ||
          b.horaSalida.localeCompare(a.horaSalida) ||
          a.id.localeCompare(b.id)
      );

    const solicitudesEnviadas = tripRequests
      .filter((r) => r.pasajeroId === currentUser.id)
      .map((req) => {
        const trip = trips.find((t) => t.id === req.viajeId);
        return { req, trip };
      })
      .filter((x): x is { req: TripRequest; trip: Trip } => x.trip != null)
      .sort(
        (a, b) =>
          b.req.fecha.localeCompare(a.req.fecha) ||
          (b.trip.horaSalida ?? "").localeCompare(a.trip.horaSalida ?? "") ||
          a.req.id.localeCompare(b.req.id)
      );

    const myTripIds = new Set(
      trips.filter((t) => t.conductorId === currentUser.id).map((t) => t.id)
    );
    const solicitudesRecibidas = tripRequests
      .filter((r) => myTripIds.has(r.viajeId))
      .map((req) => {
        const trip = trips.find((t) => t.id === req.viajeId);
        return { req, trip };
      })
      .filter((x): x is { req: TripRequest; trip: Trip } => x.trip != null)
      .sort(
        (a, b) =>
          b.req.fecha.localeCompare(a.req.fecha) ||
          (b.trip.horaSalida ?? "").localeCompare(a.trip.horaSalida ?? "") ||
          a.req.id.localeCompare(b.req.id)
      );

    return {
      proximosViajes,
      viajesPasados,
      solicitudesEnviadas,
      solicitudesRecibidas,
    };
  }, [trips, tripRequests, currentUser.id, today]);

  const TripCard = ({
    trip,
    isPast,
    onClick,
  }: {
    trip: Trip;
    isPast: boolean;
    onClick: () => void;
  }) => (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl bg-card p-4 card-shadow ${onClick ? "cursor-pointer active:scale-[0.99]" : ""} ${isPast ? "opacity-85" : ""}`}
      onClick={onClick ?? undefined}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-2">
          <MapPin size={14} className="shrink-0 text-primary" />
          <span className="truncate text-sm font-semibold text-foreground">
            {trip.origen} → {trip.destino.replace(/ \(.*\)/, "")}
          </span>
        </div>
        <span className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
          <Clock size={12} /> {trip.horaSalida}
        </span>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <img
          src={trip.conductor.avatar}
          alt=""
          className="h-6 w-6 rounded-full object-cover"
        />
        <span className="text-xs text-muted-foreground">
          {trip.conductorId === currentUser.id ? "Tú (conductor)" : trip.conductor.nombre}
        </span>
        {trip.recurrente && (
          <span className="ml-auto rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-medium text-accent">
            Recurrente
          </span>
        )}
        {onClick && (
          <ChevronRight className="ml-auto h-4 w-4 shrink-0 text-muted-foreground" />
        )}
      </div>
      {isPast && (
        <div className="mt-2 flex items-center gap-1 text-[10px] text-muted-foreground">
          <Calendar size={10} /> {trip.fecha}
        </div>
      )}
    </motion.div>
  );

  const RequestCardSent = ({
    req,
    trip,
    onOpenRide,
  }: {
    req: TripRequest;
    trip: Trip;
    onOpenRide: () => void;
  }) => (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onOpenRide}
      className="cursor-pointer rounded-2xl bg-card p-4 card-shadow transition-shadow hover:card-shadow-lg active:scale-[0.99]"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-sm font-semibold text-foreground">
          {trip.origen} → {trip.destino.replace(/ \(.*\)/, "")}
        </span>
        <RequestStatusBadge estado={req.estado} />
      </div>
      <div className="mt-2 flex items-center gap-2">
        <img
          src={trip.conductor.avatar}
          alt=""
          className="h-6 w-6 rounded-full object-cover"
        />
        <span className="text-xs text-muted-foreground">{trip.conductor.nombre}</span>
        <span className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
          {trip.fecha} · {trip.horaSalida}
          <ChevronRight size={12} className="text-muted-foreground/70" />
        </span>
      </div>
    </motion.div>
  );

  const RequestCardReceived = ({
    req,
    trip,
    onOpenRide,
  }: {
    req: TripRequest;
    trip: Trip;
    onOpenRide: () => void;
  }) => (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onOpenRide}
      className="cursor-pointer rounded-2xl bg-card p-4 card-shadow transition-shadow hover:card-shadow-lg active:scale-[0.99]"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-sm font-semibold text-foreground">
          {req.pasajero.nombre}
        </span>
        <RequestStatusBadge estado={req.estado} />
      </div>
      <div className="mt-2 flex items-center gap-2">
        <img
          src={req.pasajero.avatar}
          alt=""
          className="h-6 w-6 rounded-full object-cover"
        />
        <span className="text-xs text-muted-foreground min-w-0 truncate flex-1">
          {trip.origen} → UAL · {trip.fecha} {trip.horaSalida}
        </span>
        <ChevronRight size={12} className="text-muted-foreground/70 shrink-0" />
      </div>
      {req.estado === "pendiente" && (
        <div className="mt-3 flex gap-2" onClick={(e) => e.stopPropagation()}>
          <Button
            size="sm"
            className="flex-1 rounded-xl"
            onClick={() => updateTripRequestStatus(req.id, "aceptada")}
          >
            Aceptar
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="flex-1 rounded-xl border-destructive/50 text-destructive hover:bg-destructive/10"
            onClick={() => updateTripRequestStatus(req.id, "rechazada")}
          >
            Rechazar
          </Button>
        </div>
      )}
    </motion.div>
  );

  const Section = ({
    title,
    icon: Icon,
    count,
    children,
  }: {
    title: string;
    icon: React.ElementType;
    count: number;
    children: React.ReactNode;
  }) => (
    <section className="section-gap">
      <h2 className="section-title flex items-center gap-2">
        <Icon size={16} className="text-primary shrink-0" />
        {title}
        {count > 0 && (
          <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
            {count}
          </span>
        )}
      </h2>
      <div className="content-gap flex flex-col gap-3">
        {children}
      </div>
    </section>
  );

  const Empty = ({
    icon: Icon,
    title,
    description,
    action,
  }: {
    icon: React.ElementType;
    title: string;
    description: string;
    action?: React.ReactNode;
  }) => (
    <div className="empty-state rounded-2xl border border-dashed border-border bg-muted/30">
      <Icon className="empty-state-icon size-10" />
      <p className="empty-state-title">{title}</p>
      <p className="empty-state-desc">{description}</p>
      {action && <div className="empty-state-cta mt-4 flex gap-2">{action}</div>}
    </div>
  );

  return (
    <div className="min-h-screen bg-background safe-bottom">
      <div className="px-5 pt-12">
        <h1 className="text-xl font-bold text-foreground">Mis viajes</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Tus trayectos compartidos, historial y solicitudes
        </p>

        {/* Chat only from ride context: conversations with drivers/passengers from your trips */}
        <button
          type="button"
          onClick={() => navigate("/chat")}
          className="mt-6 flex w-full items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4 text-left card-shadow transition-shadow hover:card-shadow-lg active:scale-[0.99]"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10">
              <MessageCircle size={22} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">Conversaciones</p>
              <p className="text-xs text-muted-foreground">
                Mensajes con conductores y pasajeros de tus viajes
              </p>
            </div>
          </div>
          {totalUnread > 0 && (
            <span className="flex h-6 min-w-[24px] items-center justify-center rounded-full bg-primary px-2 text-xs font-bold text-primary-foreground">
              {totalUnread}
            </span>
          )}
          <ChevronRight size={20} className="shrink-0 text-muted-foreground" />
        </button>

        <Section
          title="Próximos viajes"
          icon={Car}
          count={proximosViajes.length}
        >
          {proximosViajes.length === 0 ? (
            <Empty
              icon={Car}
              title="Aún no tienes viajes programados"
              description="Busca plaza o ofrece tu ruta para compartir trayectos con la comunidad."
            />
          ) : (
            proximosViajes.map((trip) => (
              <TripCard
                key={trip.id}
                trip={trip}
                isPast={false}
                onClick={() => goToRide(trip.id)}
              />
            ))
          )}
        </Section>

        <Section
          title="Viajes pasados"
          icon={Calendar}
          count={viajesPasados.length}
        >
          {viajesPasados.length === 0 ? (
            <Empty
              icon={Calendar}
              title="Sin viajes pasados"
              description="Aquí aparecerán los viajes que ya hayas completado."
            />
          ) : (
            viajesPasados.map((trip) => (
              <TripCard
                key={trip.id}
                trip={trip}
                isPast
                onClick={() => goToRide(trip.id)}
              />
            ))
          )}
        </Section>

        <Section
          title="Solicitudes enviadas"
          icon={Send}
          count={solicitudesEnviadas.length}
        >
          {solicitudesEnviadas.length === 0 ? (
            <Empty
              icon={Send}
              title="Aún no has enviado solicitudes"
              description="Cuando solicites una plaza en un viaje, aparecerá aquí con su estado: pendiente, aceptada o rechazada."
              action={
                <Button
                  onClick={() => navigate("/search")}
                  variant="outline"
                  className="rounded-xl border-border font-medium"
                >
                  Buscar plaza
                </Button>
              }
            />
          ) : (
            solicitudesEnviadas.map(({ req, trip }) => (
              <RequestCardSent key={req.id} req={req} trip={trip} onOpenRide={() => goToRide(trip.id)} />
            ))
          )}
        </Section>

        <Section
          title="Solicitudes recibidas"
          icon={Inbox}
          count={solicitudesRecibidas.length}
        >
          {solicitudesRecibidas.length === 0 ? (
            <Empty
              icon={Inbox}
              title="Sin solicitudes recibidas"
              description="Cuando alguien solicite plaza en un viaje que ofreces, podrás aceptar o rechazar aquí."
            />
          ) : (
            solicitudesRecibidas.map(({ req, trip }) => (
              <RequestCardReceived key={req.id} req={req} trip={trip} onOpenRide={() => goToRide(trip.id)} />
            ))
          )}
        </Section>
      </div>
      <BottomNav />
    </div>
  );
};

export default MyTripsPage;
