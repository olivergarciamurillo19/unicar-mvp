import { useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ChevronLeft, MapPin, Clock, Users, Star, Shield,
  MessageCircle, Share2, Flag, CalendarDays, Check, Hourglass,
  CheckCircle2, XCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAppState } from "@/state/AppState";
import { toast } from "sonner";
import { VerificationBadge } from "@/components/VerificationBadge";
import { getCancellationRate, getReliabilityLabel } from "@/lib/trustUtils";
import { ReportDialog } from "@/components/ReportDialog";
import type { Report } from "@/types/unicar";
import { getAverageRating, getRatingCount, getLatestRatings } from "@/data/ratingsStore";

const RideDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [reportOpen, setReportOpen] = useState(false);
  const [isRequestingSeat, setIsRequestingSeat] = useState(false);
  const { trips, tripRequests, conversations, addTripRequest, hasRequestForTrip, addReport, currentUser } = useAppState();
  const trip = trips.find((t) => t.id === id);
  const myRequest = trip ? tripRequests.find((r) => r.viajeId === trip.id && r.pasajeroId === currentUser.id) : null;
  const alreadyRequested = !!myRequest;
  const isOwnRide = trip?.conductorId === currentUser?.id;
  const noSeatsLeft = trip ? trip.plazasLibres <= 0 : false;
  const fromPath = (location.state as { from?: string } | null)?.from ?? "/home";
  const goBack = () => navigate(fromPath === "/" ? "/home" : fromPath);
  const driverCancellationRate = trip ? getCancellationRate(trip.conductor) : 0;
  const conductorId = trip?.conductor.id ?? "";
  const driverAvgRating = trip ? (getAverageRating(conductorId) ?? trip.conductor.rating) : 0;
  const driverRatingCount = trip ? (getRatingCount(conductorId) || trip.conductor.valoraciones) : 0;
  const latestRatings = trip ? getLatestRatings(conductorId, 3) : [];
  const driverReliability = trip ? getReliabilityLabel(trip.conductor) : "—";

  const handleReportSubmit = (reason: Report["motivo"], description?: string) => {
    if (!trip) return;
    addReport(trip.conductorId, reason, description, { viajeId: trip.id });
    toast.success("Gracias por tu reporte. Revisaremos la incidencia y nos pondremos en contacto si es necesario.");
  };

  if (!trip) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-5">
        <p className="text-sm font-medium text-muted-foreground">Este viaje ya no está disponible</p>
        <div className="flex flex-col gap-2 w-full max-w-xs">
          <Button variant="outline" onClick={() => navigate("/search")} className="rounded-xl font-medium">
            Buscar plaza
          </Button>
          <Button variant="ghost" onClick={() => navigate("/home")} className="rounded-xl font-medium">
            Volver al inicio
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-10">
      {/* Header */}
      <div className="bg-primary px-5 pb-6 pt-12">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={goBack}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-foreground/15 transition-colors hover:bg-primary-foreground/25"
            aria-label="Volver"
          >
            <ChevronLeft size={20} className="text-primary-foreground" />
          </button>
          <h1 className="text-lg font-bold text-primary-foreground">Detalle del viaje</h1>
        </div>
      </div>

      <div className="px-5">
        {/* Driver card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="-mt-4 rounded-2xl bg-card p-5 card-shadow"
        >
          <div className="flex items-center gap-3">
            <div className="relative shrink-0">
              <img
                src={trip.conductor.avatar}
                alt={trip.conductor.nombre}
                className="h-14 w-14 rounded-full bg-secondary"
              />
              {trip.conductor.emailVerificado && (
                <div className="absolute -bottom-0.5 -right-0.5">
                  <VerificationBadge verified={trip.conductor.emailVerificado} variant="compact" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base font-bold text-foreground">
                  {trip.conductor.nombre}
                </h2>
                <VerificationBadge verified={trip.conductor.emailVerificado} variant="inline" className="shrink-0" />
              </div>
              <p className="text-xs text-muted-foreground">
                {trip.conductor.carrera} · {trip.conductor.curso}
              </p>
            </div>
            <div className="flex flex-col items-end shrink-0">
              <div className="flex items-center gap-1">
                <Star size={14} fill="hsl(var(--warning))" className="text-warning" />
                <span className="text-sm font-bold text-foreground">{driverAvgRating}</span>
              </div>
              <span className="text-[10px] text-muted-foreground">
                {driverRatingCount} valoraciones · {trip.conductor.numViajes} viajes
              </span>
            </div>
          </div>

          {/* Trust indicators: Puntualidad, Tasa cancelación, Fiabilidad, Valoraciones */}
          <div className="mt-4 flex gap-3">
            {[
              { label: "Puntualidad", value: `${trip.conductor.puntualidad}%` },
              { label: "Tasa cancelación", value: `${driverCancellationRate}%` },
              { label: "Fiabilidad", value: driverReliability },
              { label: "Valoraciones", value: `${driverRatingCount}` },
            ].map((stat) => (
              <div key={stat.label} className="flex-1 rounded-xl bg-secondary p-2.5 text-center">
                <p className="text-sm font-bold text-foreground">{stat.value}</p>
                <p className="text-[10px] text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Resumen de valoraciones: últimas con comentario opcional */}
          {latestRatings.length > 0 && (
            <div className="mt-4 rounded-xl bg-secondary/60 p-3">
              <p className="mb-2 text-xs font-semibold text-muted-foreground">Últimas valoraciones</p>
              <ul className="space-y-2">
                {latestRatings.map((r) => (
                  <li key={r.id} className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-2">
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            size={12}
                            className={s <= r.estrellas ? "text-warning" : "text-border"}
                            fill={s <= r.estrellas ? "currentColor" : "none"}
                          />
                        ))}
                      </div>
                      {r.deUsuarioNombre && (
                        <span className="text-[10px] text-muted-foreground">{r.deUsuarioNombre}</span>
                      )}
                    </div>
                    {r.comentario && (
                      <p className="text-xs text-foreground pl-0.5">{r.comentario}</p>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </motion.div>

        {/* Trip info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-4 rounded-2xl bg-card p-5 card-shadow"
        >
          <h3 className="section-title">Ruta y horario</h3>

          <div className="mt-4 space-y-4">
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <MapPin size={16} className="text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Origen</p>
                <p className="text-sm font-semibold text-foreground">{trip.origen}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                <MapPin size={16} className="text-accent" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Destino</p>
                <p className="text-sm font-semibold text-foreground">{trip.destino}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary">
                <Clock size={16} className="text-foreground" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Hora de salida</p>
                <p className="text-sm font-semibold text-foreground">{trip.horaSalida}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <Users size={16} className="text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Plazas disponibles</p>
                <p className="text-sm font-semibold text-primary">
                  {trip.plazasLibres} de {trip.plazasTotal}
                </p>
              </div>
            </div>
            {trip.recurrente && (
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-accent/10">
                  <CalendarDays size={16} className="text-accent" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Días recurrentes</p>
                  <div className="mt-1 flex gap-1.5">
                    {trip.diasRecurrencia?.map((d) => (
                      <span key={d} className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent text-[10px] font-semibold text-accent-foreground">
                        {d}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {trip.notas && (
            <div className="mt-4 rounded-xl bg-secondary p-3">
              <p className="text-xs text-muted-foreground">📝 {trip.notas}</p>
            </div>
          )}
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-5 flex flex-col gap-3"
        >
          {isOwnRide ? (
            <>
              <Button
                variant="outline"
                onClick={() => navigate("/trips")}
                className="h-14 w-full gap-2 rounded-2xl border-border font-medium"
              >
                Ver en Mis viajes
              </Button>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    const url = window.location.href;
                    navigator.clipboard.writeText(url).then(
                      () => toast.success("Enlace copiado al portapapeles"),
                      () => toast.error("No se pudo copiar")
                    );
                  }}
                  className="h-12 flex-1 gap-2 rounded-xl border border-border font-medium transition-colors"
                >
                  <Share2 size={18} className="text-muted-foreground shrink-0" />
                  <span className="text-sm">Compartir viaje</span>
                </Button>
              </div>
            </>
          ) : alreadyRequested && myRequest ? (
            <>
              <Button
                disabled
                className={`h-14 w-full gap-2 rounded-2xl border text-base font-semibold ${
                  myRequest.estado === "aceptada"
                    ? "border-primary/30 bg-primary/10 text-primary"
                    : myRequest.estado === "rechazada"
                      ? "border-destructive/30 bg-destructive/10 text-destructive"
                      : "border-border bg-muted text-muted-foreground"
                }`}
              >
                {myRequest.estado === "aceptada" ? (
                  <CheckCircle2 size={20} />
                ) : myRequest.estado === "rechazada" ? (
                  <XCircle size={20} />
                ) : (
                  <Hourglass size={20} />
                )}
                {myRequest.estado === "aceptada"
                  ? "Solicitud aceptada"
                  : myRequest.estado === "rechazada"
                    ? "Solicitud rechazada"
                    : "Solicitud pendiente"}
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/trips")}
                className="h-12 w-full gap-2 rounded-2xl border-border font-medium"
              >
                Ver en Mis viajes
              </Button>
            </>
          ) : noSeatsLeft ? (
            <Button
              disabled
              className="h-14 w-full gap-2 rounded-2xl border border-border bg-muted text-base font-semibold text-muted-foreground"
            >
              <Users size={20} />
              No hay plazas disponibles
            </Button>
          ) : (
            <Button
              onClick={() => {
                if (!trip || isRequestingSeat) return;
                setIsRequestingSeat(true);
                const { success, alreadyExists } = addTripRequest(trip.id);
                if (alreadyExists) {
                  toast.info("Ya tienes una solicitud en este viaje.");
                  setIsRequestingSeat(false);
                  return;
                }
                if (success) {
                  toast.success("Solicitud enviada. El conductor te contestará pronto.");
                } else {
                  toast.error("No se pudo enviar la solicitud. Inténtalo de nuevo.");
                }
                setIsRequestingSeat(false);
              }}
              disabled={isRequestingSeat || alreadyRequested}
              className="h-14 w-full gap-2 rounded-2xl bg-primary text-base font-semibold text-primary-foreground shadow-lg"
            >
              {isRequestingSeat ? (
                "Enviando..."
              ) : (
                <>
                  <Check size={20} />
                  Solicitar plaza
                </>
              )}
            </Button>
          )}

          {!isOwnRide && (
            <>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    const conv = conversations.find((c) => c.usuario.id === trip.conductorId);
                    navigate(conv ? `/chat/${conv.id}` : "/chat");
                  }}
                  className="h-12 flex-1 gap-2 rounded-xl border border-border font-medium transition-colors"
                >
                  <MessageCircle size={18} className="text-primary shrink-0" />
                  <span className="text-sm">Mensaje</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const url = window.location.href;
                    navigator.clipboard.writeText(url).then(
                      () => toast.success("Enlace copiado al portapapeles"),
                      () => toast.error("No se pudo copiar")
                    );
                  }}
                  className="h-12 flex-1 gap-2 rounded-xl border border-border font-medium transition-colors"
                >
                  <Share2 size={18} className="text-muted-foreground shrink-0" />
                  <span className="text-sm">Compartir</span>
                </Button>
              </div>

              <Button
                variant="outline"
                onClick={() => setReportOpen(true)}
                className="mt-3 w-full h-11 gap-2 rounded-xl border-destructive/50 text-destructive hover:bg-destructive/10 hover:border-destructive"
              >
                <Flag size={16} />
                Reportar incidencia
              </Button>
            </>
          )}
        </motion.div>

        <ReportDialog
          open={reportOpen}
          onOpenChange={setReportOpen}
          reportedUserName={trip.conductor.nombre}
          onSubmit={handleReportSubmit}
        />
      </div>
    </div>
  );
};

export default RideDetailPage;
