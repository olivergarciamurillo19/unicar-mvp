import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronLeft, Send, Flag } from "lucide-react";
import { toast } from "sonner";
import { useAppState } from "@/state/AppState";
import BottomNav from "@/components/BottomNav";
import { ReportDialog } from "@/components/ReportDialog";
import { VerificationBadge } from "@/components/VerificationBadge";
import { ChatTrustBanner } from "@/components/ChatTrustBanner";
import { redactPhoneNumbers } from "@/lib/chatSafety";
import type { Report } from "@/types/unicar";

const MAX_MESSAGE_LENGTH = 2000;

const ChatConversationPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [newMsg, setNewMsg] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const { messages, conversations, currentUser, addMessage, addReport, markConversationAsRead } = useAppState();
  const convId = id ?? "";
  const messagesList = messages[convId] ?? [];
  const conv = conversations.find((c) => c.id === id);
  const conversationNotFound = Boolean(id && !conv);
  useEffect(() => {
    if (id) markConversationAsRead(id);
  }, [id, markConversationAsRead]);

  const handleReportSubmit = (reason: Report["motivo"], description?: string) => {
    if (!conv) return;
    addReport(conv.usuario.id, reason, description, { conversacionId: conv.id });
    toast.success("Gracias por tu reporte. Revisaremos la incidencia y nos pondremos en contacto si es necesario.");
  };

  const sendMessage = () => {
    const trimmed = newMsg.trim();
    if (!trimmed || !conv || isSending) return;
    if (trimmed.length > MAX_MESSAGE_LENGTH) {
      toast.error(`El mensaje no puede superar ${MAX_MESSAGE_LENGTH} caracteres`);
      return;
    }
    setIsSending(true);
    try {
      addMessage(convId, {
        id: `m_${Date.now()}`,
        emisorId: currentUser.id,
        receptorId: conv.usuario.id,
        mensaje: trimmed,
        fecha: new Date().toISOString(),
        leido: false,
      });
      setNewMsg("");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-background pb-24">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-border bg-card px-4 pb-3 pt-12">
        <button
          onClick={() => navigate("/chat")}
          className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary"
        >
          <ChevronLeft size={20} className="text-foreground" />
        </button>
        {conversationNotFound ? (
          <div className="flex-1 min-w-0 flex flex-col gap-0.5">
            <span className="text-sm font-medium text-muted-foreground">Esta conversación no existe</span>
            <span className="text-xs text-muted-foreground">Usa el botón atrás para volver al listado.</span>
          </div>
        ) : conv ? (
          <>
            <img
              src={conv.usuario.avatar}
              alt={conv.usuario.nombre}
              className="h-9 w-9 rounded-full bg-secondary"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm font-semibold text-foreground truncate">
                  {conv.usuario.nombre}
                </h2>
                <VerificationBadge verified={conv.usuario.emailVerificado} variant="inline" className="shrink-0" />
              </div>
              <p className="text-[10px] text-muted-foreground">
                {conv.usuario.carrera}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setReportOpen(true)}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-destructive/50 text-destructive hover:bg-destructive/10"
              aria-label="Reportar usuario"
              title="Reportar usuario"
            >
              <Flag size={18} />
            </button>
          </>
        ) : null}
      </div>
      {conv && (
        <ReportDialog
          open={reportOpen}
          onOpenChange={setReportOpen}
          reportedUserName={conv.usuario.nombre}
          onSubmit={handleReportSubmit}
        />
      )}

      {/* Trust message — no contact info shown in chat */}
      <div className="shrink-0 border-b border-border bg-muted/30 px-4 py-2.5">
        <ChatTrustBanner />
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        {conversationNotFound ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 py-12 text-center">
            <p className="text-sm font-medium text-muted-foreground">Esta conversación no existe o ya no está disponible.</p>
            <button
              type="button"
              onClick={() => navigate("/chat")}
              className="text-sm font-semibold text-primary hover:underline"
            >
              Volver a mensajes
            </button>
          </div>
        ) : (
        <div className="flex flex-col gap-2">
          {messagesList.map((msg, i) => {
            const isMe = msg.emisorId === currentUser.id;
            return (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className={`flex ${isMe ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                    isMe
                      ? "rounded-br-md bg-primary text-primary-foreground"
                      : "rounded-bl-md bg-card text-foreground card-shadow"
                  }`}
                >
                  <p>{redactPhoneNumbers(msg.mensaje)}</p>
                  <p
                    className={`mt-1 text-[10px] ${
                      isMe ? "text-primary-foreground/60" : "text-muted-foreground"
                    }`}
                  >
                    {new Date(msg.fecha).toLocaleTimeString("es-ES", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
        )}
      </div>

      {/* Input — only when conversation exists */}
      {conv && (
        <div className="shrink-0 border-t border-border bg-card p-3">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={newMsg}
              onChange={(e) => setNewMsg(e.target.value.slice(0, MAX_MESSAGE_LENGTH))}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
              placeholder="Escribe un mensaje..."
              maxLength={MAX_MESSAGE_LENGTH}
              disabled={isSending}
              className="h-11 flex-1 rounded-xl border border-border bg-background px-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-70"
            />
            <button
              type="button"
              onClick={sendMessage}
              disabled={!newMsg.trim() || isSending}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary disabled:opacity-50 disabled:pointer-events-none"
              aria-label="Enviar mensaje"
            >
              <Send size={18} className="text-primary-foreground" />
            </button>
          </div>
        </div>
      )}
      <BottomNav />
    </div>
  );
};

export default ChatConversationPage;
