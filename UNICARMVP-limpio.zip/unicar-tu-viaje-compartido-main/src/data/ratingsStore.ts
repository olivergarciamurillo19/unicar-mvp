import type { Rating } from "@/types/unicar";

/**
 * Capa de valoraciones MVP: todo en memoria.
 * [Supabase] Replace with supabase.from('ratings').select() and related queries. See docs/REALTIME_READINESS_MIGRATION_PLAN.md
 * Estructura: 1-5 estrellas + comentario opcional.
 */

const ratings: Rating[] = [
  // Valoraciones para Carlos (u1) — conductor
  { id: "rv1", deUsuarioId: "u0", paraUsuarioId: "u1", viajeId: "t1", estrellas: 5, comentario: "Muy puntual y buena conversación. Repetiré.", fecha: "2026-03-10T09:00:00", deUsuarioNombre: "Ana T." },
  { id: "rv2", deUsuarioId: "u2", paraUsuarioId: "u1", viajeId: "t1", estrellas: 5, comentario: "Siempre a la hora. Muy recomendable.", fecha: "2026-03-09T08:30:00", deUsuarioNombre: "María L." },
  { id: "rv3", deUsuarioId: "u4", paraUsuarioId: "u1", viajeId: "t1", estrellas: 4, comentario: "Todo bien, un día llegó 2 min tarde.", fecha: "2026-03-08T08:15:00", deUsuarioNombre: "Laura F." },
  { id: "rv4", deUsuarioId: "u5", paraUsuarioId: "u1", viajeId: "t1", estrellas: 5, fecha: "2026-03-07T09:00:00", deUsuarioNombre: "Pablo R." },
  { id: "rv5", deUsuarioId: "u6", paraUsuarioId: "u1", viajeId: "t1", estrellas: 5, comentario: "Genial viaje compartido.", fecha: "2026-03-06T08:45:00", deUsuarioNombre: "Carmen H." },
  // Valoraciones para María (u2)
  { id: "rv6", deUsuarioId: "u0", paraUsuarioId: "u2", viajeId: "t2", estrellas: 5, comentario: "Encantadora. Punto de recogida claro.", fecha: "2026-03-12T08:00:00", deUsuarioNombre: "Ana T." },
  { id: "rv7", deUsuarioId: "u1", paraUsuarioId: "u2", viajeId: "t2", estrellas: 5, comentario: "Música suave, muy agradable.", fecha: "2026-03-11T07:50:00", deUsuarioNombre: "Carlos M." },
  { id: "rv8", deUsuarioId: "u3", paraUsuarioId: "u2", viajeId: "t2", estrellas: 4, comentario: "Todo correcto.", fecha: "2026-03-10T08:00:00", deUsuarioNombre: "Alejandro G." },
  // Valoraciones para Alejandro (u3)
  { id: "rv9", deUsuarioId: "u0", paraUsuarioId: "u3", viajeId: "t3", estrellas: 4, comentario: "Llegó justo a tiempo. Bien.", fecha: "2026-03-09T07:35:00", deUsuarioNombre: "Ana T." },
  { id: "rv10", deUsuarioId: "u2", paraUsuarioId: "u3", viajeId: "t3", estrellas: 5, comentario: "Muy serio con los horarios.", fecha: "2026-03-08T07:40:00", deUsuarioNombre: "María L." },
  { id: "rv11", deUsuarioId: "u5", paraUsuarioId: "u3", viajeId: "t3", estrellas: 4, fecha: "2026-03-07T07:30:00", deUsuarioNombre: "Pablo R." },
  // Valoraciones para Laura (u4)
  { id: "rv12", deUsuarioId: "u0", paraUsuarioId: "u4", viajeId: "t4", estrellas: 5, comentario: "Puerta Purchena perfecto. Puntual.", fecha: "2026-03-11T08:35:00", deUsuarioNombre: "Ana T." },
  { id: "rv13", deUsuarioId: "u1", paraUsuarioId: "u4", viajeId: "t4", estrellas: 5, comentario: "Muy buena conductora.", fecha: "2026-03-10T08:40:00", deUsuarioNombre: "Carlos M." },
  // Valoraciones para Pablo (u5)
  { id: "rv14", deUsuarioId: "u0", paraUsuarioId: "u5", viajeId: "t5", estrellas: 4, comentario: "Flexible con el punto de recogida.", fecha: "2026-03-06T07:20:00", deUsuarioNombre: "Ana T." },
  { id: "rv15", deUsuarioId: "u3", paraUsuarioId: "u5", viajeId: "t5", estrellas: 5, fecha: "2026-03-05T07:25:00", deUsuarioNombre: "Alejandro G." },
  { id: "rv16", deUsuarioId: "u6", paraUsuarioId: "u5", viajeId: "t5", estrellas: 4, comentario: "Bien, sin incidencias.", fecha: "2026-03-04T07:15:00", deUsuarioNombre: "Carmen H." },
  // Valoraciones para Carmen (u6)
  { id: "rv17", deUsuarioId: "u0", paraUsuarioId: "u6", viajeId: "t6", estrellas: 5, comentario: "Horario flexible, muy maja.", fecha: "2026-03-08T09:05:00", deUsuarioNombre: "Ana T." },
  { id: "rv18", deUsuarioId: "u2", paraUsuarioId: "u6", viajeId: "t6", estrellas: 5, comentario: "Recojo en el Día genial.", fecha: "2026-03-07T09:00:00", deUsuarioNombre: "María L." },
  { id: "rv19", deUsuarioId: "u4", paraUsuarioId: "u6", viajeId: "t6", estrellas: 4, fecha: "2026-03-06T09:10:00", deUsuarioNombre: "Laura F." },
  // Valoraciones para Ana (u0) — usuaria actual
  { id: "rv20", deUsuarioId: "u1", paraUsuarioId: "u0", viajeId: "t1", estrellas: 5, comentario: "Muy buena pasajera, puntual.", fecha: "2026-03-10T09:10:00", deUsuarioNombre: "Carlos M." },
  { id: "rv21", deUsuarioId: "u2", paraUsuarioId: "u0", viajeId: "t2", estrellas: 5, comentario: "Encantadora. Recomendada.", fecha: "2026-03-12T08:15:00", deUsuarioNombre: "María L." },
  { id: "rv22", deUsuarioId: "u4", paraUsuarioId: "u0", viajeId: "t4", estrellas: 4, comentario: "Todo bien.", fecha: "2026-03-11T08:45:00", deUsuarioNombre: "Laura F." },
  { id: "rv23", deUsuarioId: "u3", paraUsuarioId: "u0", viajeId: "t3", estrellas: 5, fecha: "2026-03-09T07:45:00", deUsuarioNombre: "Alejandro G." },
];

export function getRatingsForUser(paraUsuarioId: string): Rating[] {
  return ratings.filter((r) => r.paraUsuarioId === paraUsuarioId);
}

export function getAverageRating(paraUsuarioId: string): number | null {
  const list = getRatingsForUser(paraUsuarioId);
  if (list.length === 0) return null;
  const sum = list.reduce((acc, r) => acc + r.estrellas, 0);
  return Math.round((sum / list.length) * 10) / 10;
}

export function getRatingCount(paraUsuarioId: string): number {
  return getRatingsForUser(paraUsuarioId).length;
}

/** Últimas N valoraciones (por fecha descendente), con comentario o sin él. */
export function getLatestRatings(paraUsuarioId: string, limit: number): Rating[] {
  return getRatingsForUser(paraUsuarioId)
    .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
    .slice(0, limit);
}

export { ratings as demoRatings };
