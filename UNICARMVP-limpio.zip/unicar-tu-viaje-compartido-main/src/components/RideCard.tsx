import { Star, Clock, Users, ChevronRight } from "lucide-react";
import { Trip } from "@/types/unicar";
import { motion } from "framer-motion";
import { VerificationBadge } from "@/components/VerificationBadge";
import { getCancellationRate } from "@/lib/trustUtils";
import { getAverageRating, getRatingCount } from "@/data/ratingsStore";

interface RideCardProps {
  trip: Trip;
  onClick?: () => void;
  compact?: boolean;
}

const RideCard = ({ trip, onClick }: RideCardProps) => {
  const seatsArray = Array.from({ length: trip.plazasTotal }, (_, i) => i < trip.plazasTotal - trip.plazasLibres);
  const conductorId = trip.conductor.id;
  const avgRating = getAverageRating(conductorId) ?? trip.conductor.rating;
  const ratingCount = getRatingCount(conductorId) || trip.conductor.valoraciones;

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="cursor-pointer rounded-2xl border border-border/60 bg-card p-4 card-shadow transition-all hover:card-shadow-lg hover:border-border active:scale-[0.98]"
    >
      {/* Top: Route + Time – primary hierarchy */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="flex flex-col items-center gap-0.5 shrink-0">
            <div className="h-2.5 w-2.5 rounded-full border-2 border-primary bg-card" />
            <div className="h-5 w-0.5 bg-gradient-to-b from-primary to-accent" />
            <div className="h-2.5 w-2.5 rounded-full bg-primary" />
          </div>
          <div className="flex flex-col gap-0.5 min-w-0">
            <span className="text-sm font-bold text-foreground truncate">{trip.origen}</span>
            <span className="text-xs text-muted-foreground truncate">{trip.destino}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-0.5 shrink-0">
          <div className="flex items-center gap-1.5 text-foreground">
            <Clock size={14} className="text-muted-foreground shrink-0" />
            <span className="text-sm font-bold tabular-nums">{trip.horaSalida}</span>
          </div>
          <span className="text-[10px] text-muted-foreground">{trip.fecha}</span>
        </div>
      </div>

      {/* Divider */}
      <div className="my-3.5 h-px bg-border" />

      {/* Bottom: Driver + Seats – secondary hierarchy */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <img
              src={trip.conductor.avatar}
              alt={trip.conductor.nombre}
              className="h-10 w-10 rounded-full bg-secondary object-cover ring-2 ring-card"
            />
            {trip.conductor.emailVerificado && (
              <div className="absolute -bottom-0.5 -right-0.5">
                <VerificationBadge verified={trip.conductor.emailVerificado} variant="compact" />
              </div>
            )}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">{trip.conductor.nombre}</p>
            <div className="flex items-center gap-1.5 text-muted-foreground flex-wrap">
              <Star size={12} className="text-warning shrink-0" fill="currentColor" />
              <span className="text-xs font-medium text-foreground">{avgRating}</span>
              <span className="text-[10px]">· {ratingCount} valoraciones</span>
              <span className="text-[10px]">· {trip.conductor.numViajes} viajes</span>
              <span className="text-[10px]">· {getCancellationRate(trip.conductor)}% canc.</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1">
            <Users size={14} className="text-muted-foreground shrink-0" />
            {seatsArray.map((taken, i) => (
              <div
                key={i}
                className={`h-2.5 w-2.5 rounded-full ${taken ? "bg-muted-foreground/25" : "bg-primary"}`}
              />
            ))}
          </div>
          <ChevronRight size={18} className="text-muted-foreground/40" />
        </div>
      </div>

      {/* Tags */}
      {(trip.recurrente || trip.notas) && (
        <div className="mt-3 flex flex-wrap gap-2">
          {trip.recurrente && (
            <span className="rounded-full bg-accent/10 px-2.5 py-1 text-[10px] font-semibold text-accent">
              🔄 {trip.diasRecurrencia?.join(", ")}
            </span>
          )}
          {trip.notas && (
            <span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-medium text-muted-foreground truncate max-w-[200px]">
              💬 {trip.notas}
            </span>
          )}
        </div>
      )}
    </motion.div>
  );
};

export default RideCard;
