import { useState } from "react";
import { Flag } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import type { Report } from "@/types/unicar";

const MAX_DESCRIPTION_LENGTH = 1000;

const REPORT_REASONS: { value: Report["motivo"]; label: string }[] = [
  { value: "no_se_presento", label: "No se presentó" },
  { value: "comportamiento_inapropiado", label: "Comportamiento inapropiado" },
  { value: "informacion_falsa", label: "Información falsa" },
  { value: "spam", label: "Spam" },
];

interface ReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reportedUserName: string;
  onSubmit: (reason: Report["motivo"], description?: string) => void;
}

export function ReportDialog({
  open,
  onOpenChange,
  reportedUserName,
  onSubmit,
}: ReportDialogProps) {
  const [reason, setReason] = useState<Report["motivo"] | "">("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleOpenChange = (next: boolean) => {
    if (!next) {
      setReason("");
      setDescription("");
    }
    onOpenChange(next);
  };

  const handleSubmit = () => {
    if (!reason) return;
    if (isSubmitting) return;
    const descTrimmed = description.trim();
    if (descTrimmed.length > MAX_DESCRIPTION_LENGTH) {
      toast.error(`Los detalles no pueden superar ${MAX_DESCRIPTION_LENGTH} caracteres`);
      return;
    }
    setIsSubmitting(true);
    try {
      onSubmit(reason, descTrimmed || undefined);
      setReason("");
      setDescription("");
      onOpenChange(false);
    } catch (err) {
      toast.error("No se pudo enviar el reporte. Inténtalo de nuevo.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-[90vw] rounded-2xl sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-destructive/10">
              <Flag size={20} className="text-destructive" />
            </div>
            <DialogTitle className="text-left">Reportar incidencia</DialogTitle>
          </div>
          <DialogDescription className="text-left">
            Indica el motivo del reporte sobre <strong>{reportedUserName}</strong>. Revisamos cada incidencia y nos pondremos en contacto si es necesario.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="reason">Motivo</Label>
            <Select value={reason} onValueChange={(v) => setReason(v as Report["motivo"])}>
              <SelectTrigger id="reason" className="rounded-xl">
                <SelectValue placeholder="Selecciona un motivo" />
              </SelectTrigger>
              <SelectContent>
                {REPORT_REASONS.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="desc">Detalles (opcional, máx. {MAX_DESCRIPTION_LENGTH} caracteres)</Label>
            <Textarea
              id="desc"
              placeholder="Añade más información si lo deseas..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={MAX_DESCRIPTION_LENGTH}
              className="min-h-[80px] rounded-xl resize-none"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => handleOpenChange(false)} className="rounded-xl">
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!reason || isSubmitting}
            className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {isSubmitting ? "Enviando..." : "Enviar reporte"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
