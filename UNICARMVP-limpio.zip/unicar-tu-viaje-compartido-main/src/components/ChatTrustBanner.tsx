import { Shield } from "lucide-react";

const TRUST_MESSAGE =
  "Por tu seguridad, mantén la comunicación dentro de UniCar. Comunidad UAL verificada.";

export function ChatTrustBanner() {
  return (
    <div
      className="flex items-center gap-3 rounded-xl border border-primary/20 bg-primary/5 px-4 py-3"
      role="status"
      aria-live="polite"
    >
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10">
        <Shield size={18} className="text-primary" />
      </div>
      <p className="text-sm font-medium text-foreground">{TRUST_MESSAGE}</p>
    </div>
  );
}
