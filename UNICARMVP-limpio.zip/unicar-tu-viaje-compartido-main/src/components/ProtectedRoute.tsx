import { Navigate, Outlet, useLocation } from "react-router-dom";
import { isAuthenticated } from "@/lib/demoAuth";

/**
 * Protects: /home, /search, /create, /ride/:id, /chat, /chat/:id, /trips, /profile.
 * If no demo session in localStorage, redirects to /auth with state.from for post-login return.
 */
export function ProtectedRoute() {
  const location = useLocation();
  if (!isAuthenticated()) {
    return <Navigate to="/auth" state={{ from: location.pathname }} replace />;
  }
  return <Outlet />;
}
