import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const UAL_COORDS: [number, number] = [36.8282, -2.4032];

const ROUTE_POINTS: { label: string; coords: [number, number]; riders: number }[] = [
  { label: "Roquetas de Mar", coords: [36.7643, -2.6147], riders: 5 },
  { label: "Aguadulce", coords: [36.8092, -2.5574], riders: 3 },
  { label: "El Ejido", coords: [36.7764, -2.8144], riders: 4 },
  { label: "Almería Centro", coords: [36.8381, -2.4597], riders: 6 },
  { label: "Vícar", coords: [36.8316, -2.6425], riders: 2 },
  { label: "Huércal de Almería", coords: [36.8879, -2.4371], riders: 3 },
];

const HomeMap = () => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    const map = L.map(mapRef.current, {
      zoomControl: false,
      attributionControl: false,
      dragging: true,
      scrollWheelZoom: false,
    }).setView([36.82, -2.55], 11);

    L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
    }).addTo(map);

    // UAL marker
    const ualIcon = L.divIcon({
      html: `<div style="background:hsl(160,84%,39%);width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
      </div>`,
      className: "",
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });
    L.marker(UAL_COORDS, { icon: ualIcon }).addTo(map).bindPopup(
      '<strong style="font-size:13px;">Universidad de Almería</strong><br/><span style="color:#666;font-size:11px;">Destino principal</span>'
    );

    // Route points
    ROUTE_POINTS.forEach((point) => {
      const icon = L.divIcon({
        html: `<div style="background:hsl(217,91%,60%);color:white;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.25);">${point.riders}</div>`,
        className: "",
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });

      L.marker(point.coords, { icon })
        .addTo(map)
        .bindPopup(
          `<strong style="font-size:13px;">${point.label}</strong><br/><span style="color:hsl(160,84%,39%);font-size:12px;font-weight:600;">${point.riders} conductores activos</span>`
        );

      // Draw route line to UAL
      L.polyline([point.coords, UAL_COORDS], {
        color: "hsl(217,91%,60%)",
        weight: 2,
        opacity: 0.3,
        dashArray: "6 8",
      }).addTo(map);
    });

    mapInstance.current = map;

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  return (
    <div
      ref={mapRef}
      className="h-full w-full rounded-2xl"
      style={{ minHeight: 200 }}
    />
  );
};

export default HomeMap;
