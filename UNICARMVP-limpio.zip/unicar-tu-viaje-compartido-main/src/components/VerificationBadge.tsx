import { Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface VerificationBadgeProps {
  verified: boolean;
  /** "compact" = icon only on avatar; "inline" = icon + "Verificado UAL" text */
  variant?: "compact" | "inline";
  className?: string;
}

export function VerificationBadge({ verified, variant = "inline", className }: VerificationBadgeProps) {
  if (!verified) return null;

  if (variant === "compact") {
    return (
      <div
        className={cn(
          "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-trust text-trust-foreground ring-2 ring-card",
          className
        )}
        title="Verificado UAL"
        aria-label="Usuario verificado UAL"
      >
        <Shield size={12} strokeWidth={2.5} />
      </div>
    );
  }

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full bg-trust/15 px-2.5 py-1 text-xs font-semibold text-trust",
        className
      )}
      aria-label="Cuenta verificada UAL"
    >
      <Shield size={12} strokeWidth={2.5} />
      Verificado UAL
    </span>
  );
}
