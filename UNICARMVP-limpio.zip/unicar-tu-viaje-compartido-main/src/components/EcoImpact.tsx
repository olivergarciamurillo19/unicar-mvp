import { Car, Cloud, Fuel, TrendingDown } from "lucide-react";
import { useAppState } from "@/state/AppState";

/** Each accepted shared ride = 1 car removed; each car ≈ 2.3 kg CO₂, 4.5 L fuel (demo-friendly). */
const CO2_KG_PER_CAR = 2.3;
const LITERS_FUEL_PER_CAR = 4.5;
/** Notional baseline cars for traffic reduction % (campus-scale demo). */
const BASELINE_CARS = 130;

const EcoImpact = () => {
  const { tripRequests } = useAppState();
  const acceptedSharedRides = tripRequests.filter((r) => r.estado === "aceptada").length;

  const carsRemoved = acceptedSharedRides;
  const co2AvoidedKg = Math.round(acceptedSharedRides * CO2_KG_PER_CAR);
  const gasSavedLiters = Math.round(acceptedSharedRides * LITERS_FUEL_PER_CAR);
  const trafficReductionPercent = Math.min(40, Math.round((carsRemoved / BASELINE_CARS) * 100));

  const stats = [
    {
      icon: Car,
      value: String(carsRemoved),
      label: "Coches menos en el campus",
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      icon: Cloud,
      value: `${co2AvoidedKg} kg`,
      label: "CO₂ que no se emitió",
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      icon: Fuel,
      value: `~${gasSavedLiters} L`,
      label: "Combustible ahorrado",
      color: "text-warning",
      bg: "bg-warning/10",
    },
    {
      icon: TrendingDown,
      value: `~${trafficReductionPercent}%`,
      label: "Menos atascos",
      color: "text-accent",
      bg: "bg-accent/10",
    },
  ];

  return (
    <section className="w-full">
      <h2 className="section-title-lg">Tu impacto, nuestra huella</h2>
      <p className="section-subtitle">
        Lo que la comunidad UAL ha ahorrado este curso compartiendo trayecto
      </p>
      <div className="content-gap grid grid-cols-2 gap-2.5">
        {stats.map((stat, i) => (
          <div
            key={i}
            className="flex items-center gap-3 rounded-2xl border border-border/50 bg-card p-3.5 card-shadow"
          >
            <div
              className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${stat.bg} ${stat.color}`}
            >
              <stat.icon size={20} />
            </div>
            <div className="min-w-0">
              <p className="text-base font-bold text-foreground leading-tight truncate">
                {stat.value}
              </p>
              <p className="text-[10px] text-muted-foreground leading-tight">
                {stat.label}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default EcoImpact;
