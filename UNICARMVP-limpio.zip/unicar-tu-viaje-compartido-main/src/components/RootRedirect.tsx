import { Navigate } from "react-router-dom";
import { isAuthenticated } from "@/lib/demoAuth";

/**
 * "/" redirects to /home when logged in, otherwise to /auth.
 */
export function RootRedirect() {
  return <Navigate to={isAuthenticated() ? "/home" : "/auth"} replace />;
}
