import {
  createContext,
  useContext,
  useMemo,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import type { User, Trip, TripRequest, ChatConversation, ChatMessage, Report, ReportMotivo } from "@/types/unicar";
import {
  currentUser as seedCurrentUser,
  demoTrips as seedTrips,
  demoRequests as seedRequests,
  demoConversations as seedConversations,
  demoMessages as seedMessages,
} from "@/data/demoData";

export type TripRequestEstado = TripRequest["estado"];

export interface AppStateValue {
  currentUser: User;
  trips: Trip[];
  tripRequests: TripRequest[];
  conversations: ChatConversation[];
  messages: Record<string, ChatMessage[]>;
  reports: Report[];
  addMessage: (conversationId: string, message: ChatMessage) => void;
  addTrip: (trip: Trip) => void;
  addTripRequest: (viajeId: string) => { success: boolean; alreadyExists?: boolean };
  updateTripRequestStatus: (requestId: string, estado: "aceptada" | "rechazada") => boolean;
  hasRequestForTrip: (viajeId: string) => boolean;
  addReport: (reportadoId: string, motivo: ReportMotivo, descripcion?: string, context?: { viajeId?: string; conversacionId?: string }) => void;
  addConversation: (conversation: ChatConversation) => void;
  markConversationAsRead: (conversationId: string) => void;
}

const AppStateContext = createContext<AppStateValue | null>(null);

/** [Supabase] Replace with fetch from Supabase (rides, trip_requests, conversations, messages). See docs/REALTIME_READINESS_MIGRATION_PLAN.md */
function getInitialState(): Omit<AppStateValue, "addMessage" | "addTrip" | "addTripRequest" | "updateTripRequestStatus" | "hasRequestForTrip" | "addReport" | "addConversation" | "markConversationAsRead"> {
  return {
    currentUser: seedCurrentUser,
    trips: [...seedTrips],
    tripRequests: [...seedRequests],
    conversations: [...seedConversations],
    messages: Object.fromEntries(
      Object.entries(seedMessages).map(([k, list]) => [k, [...list]])
    ),
    reports: [] as Report[],
  };
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState(getInitialState);

  /** [Supabase] Replace with supabase.from('rides').insert(). */
  const addTrip = useCallback((trip: Trip) => {
    setState((prev) => ({
      ...prev,
      trips: [...prev.trips, trip],
    }));
  }, []);

  /** [Supabase] Replace with supabase.from('messages').insert() + optional Realtime. */
  const addMessage = useCallback((conversationId: string, message: ChatMessage) => {
    setState((prev) => {
      const nextMessages = {
        ...prev.messages,
        [conversationId]: [...(prev.messages[conversationId] ?? []), message],
      };
      const convIdx = prev.conversations.findIndex((c) => c.id === conversationId);
      if (convIdx < 0) {
        return { ...prev, messages: nextMessages };
      }
      const conv = prev.conversations[convIdx];
      const updatedConv: ChatConversation = {
        ...conv,
        ultimoMensaje: message.mensaje,
        fecha: message.fecha,
        noLeidos: message.receptorId === prev.currentUser.id ? conv.noLeidos + 1 : conv.noLeidos,
      };
      const nextConversations = [...prev.conversations];
      nextConversations[convIdx] = updatedConv;
      return { ...prev, messages: nextMessages, conversations: nextConversations };
    });
  }, []);

  /** [Supabase] Replace with supabase.from('trip_requests').update({ estado }). When aceptada, also update rides.plazas_libres. */
  const updateTripRequestStatus = useCallback(
    (requestId: string, estado: "aceptada" | "rechazada"): boolean => {
      setState((prev) => {
        const reqIdx = prev.tripRequests.findIndex((r) => r.id === requestId);
        if (reqIdx < 0) return prev;
        const req = prev.tripRequests[reqIdx];
        if (req.estado !== "pendiente") return prev;
        const nextRequests = prev.tripRequests.map((r, i) =>
          i === reqIdx ? { ...r, estado } : r
        );
        if (estado !== "aceptada") {
          return { ...prev, tripRequests: nextRequests };
        }
        const tripIdx = prev.trips.findIndex((t) => t.id === req.viajeId);
        if (tripIdx < 0) return { ...prev, tripRequests: nextRequests };
        const trip = prev.trips[tripIdx];
        const nextPlazas = Math.max(0, trip.plazasLibres - 1);
        const nextTrips = prev.trips.map((t, i) =>
          i === tripIdx ? { ...t, plazasLibres: nextPlazas } : t
        );
        return { ...prev, tripRequests: nextRequests, trips: nextTrips };
      });
      return true;
    },
    []
  );

  /** [Supabase] Replace with query trip_requests by ride_id + current user id. */
  const hasRequestForTrip = useCallback(
    (viajeId: string) =>
      state.tripRequests.some(
        (r) => r.viajeId === viajeId && r.pasajeroId === state.currentUser.id
      ),
    [state.tripRequests, state.currentUser.id]
  );

  /** [Supabase] Replace with supabase.from('trip_requests').insert(); consider updating rides.plazas_libres. */
  const addTripRequest = useCallback(
    (viajeId: string): { success: boolean; alreadyExists?: boolean } => {
      const trip = state.trips.find((t) => t.id === viajeId);
      if (!trip) return { success: false };
      if (
        state.tripRequests.some(
          (r) => r.viajeId === viajeId && r.pasajeroId === state.currentUser.id
        )
      ) {
        return { success: false, alreadyExists: true };
      }
      setState((prev) => {
        const alreadyExists = prev.tripRequests.some(
          (r) => r.viajeId === viajeId && r.pasajeroId === prev.currentUser.id
        );
        if (alreadyExists) return prev;
        const newRequest: TripRequest = {
          id: `r-${viajeId}-${prev.currentUser.id}-${Date.now()}`,
          viajeId,
          pasajeroId: prev.currentUser.id,
          pasajero: prev.currentUser,
          estado: "pendiente",
          fecha: new Date().toISOString().slice(0, 10),
        };
        const tripFromPrev = prev.trips.find((t) => t.id === viajeId);
        if (!tripFromPrev) return prev;
        let nextConversations = prev.conversations;
        const hasConvWithDriver = prev.conversations.some(
          (c) => c.usuario.id === tripFromPrev.conductorId
        );
        if (!hasConvWithDriver && tripFromPrev.conductorId !== prev.currentUser.id) {
          const newConv: ChatConversation = {
            id: `c-${tripFromPrev.conductorId}-${prev.currentUser.id}-${Date.now()}`,
            usuario: tripFromPrev.conductor,
            ultimoMensaje: "",
            fecha: new Date().toISOString(),
            noLeidos: 0,
          };
          nextConversations = [...prev.conversations, newConv];
        }
        return {
          ...prev,
          tripRequests: [...prev.tripRequests, newRequest],
          conversations: nextConversations,
        };
      });
      return { success: true };
    },
    [state.tripRequests, state.currentUser, state.trips]
  );

  /** [Supabase] Replace with supabase.from('reports').insert(). */
  const addReport = useCallback(
    (
      reportadoId: string,
      motivo: ReportMotivo,
      descripcion?: string,
      context?: { viajeId?: string; conversacionId?: string }
    ) => {
      const report: Report = {
        id: `rep-${Date.now()}-${reportadoId}`,
        reportadoPorId: state.currentUser.id,
        reportadoId,
        motivo,
        descripcion,
        fecha: new Date().toISOString(),
        ...context,
      };
      setState((prev) => ({
        ...prev,
        reports: [...prev.reports, report],
      }));
    },
    [state.currentUser.id]
  );

  const addConversation = useCallback((conversation: ChatConversation) => {
    setState((prev) => {
      if (prev.conversations.some((c) => c.usuario.id === conversation.usuario.id)) {
        return prev;
      }
      return { ...prev, conversations: [...prev.conversations, conversation] };
    });
  }, []);

  const markConversationAsRead = useCallback((conversationId: string) => {
    setState((prev) => {
      const idx = prev.conversations.findIndex((c) => c.id === conversationId);
      if (idx < 0 || prev.conversations[idx].noLeidos === 0) return prev;
      const next = [...prev.conversations];
      next[idx] = { ...next[idx], noLeidos: 0 };
      return { ...prev, conversations: next };
    });
  }, []);

  const value = useMemo<AppStateValue>(
    () => ({
      ...state,
      addMessage,
      addTrip,
      addTripRequest,
      updateTripRequestStatus,
      hasRequestForTrip,
      addReport,
      addConversation,
      markConversationAsRead,
    }),
    [
      state,
      addMessage,
      addTrip,
      addTripRequest,
      updateTripRequestStatus,
      hasRequestForTrip,
      addReport,
      addConversation,
      markConversationAsRead,
    ]
  );

  return (
    <AppStateContext.Provider value={value}>
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState(): AppStateValue {
  const ctx = useContext(AppStateContext);
  if (!ctx) {
    throw new Error("useAppState must be used within AppStateProvider");
  }
  return ctx;
}
