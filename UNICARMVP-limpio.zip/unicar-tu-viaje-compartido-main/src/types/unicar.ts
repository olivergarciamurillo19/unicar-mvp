export interface User {
  id: string;
  nombre: string;
  correo: string;
  avatar: string;
  carrera: string;
  curso: string;
  emailVerificado: boolean;
  rating: number;
  numViajes: number;
  puntualidad: number;
  cancelaciones: number;
  valoraciones: number;
}

export interface Trip {
  id: string;
  conductorId: string;
  conductor: User;
  origen: string;
  destino: string;
  horaSalida: string;
  fecha: string;
  plazasTotal: number;
  plazasLibres: number;
  recurrente: boolean;
  diasRecurrencia?: string[];
  notas?: string;
  estado: "activo" | "completado" | "cancelado";
}

export interface TripRequest {
  id: string;
  viajeId: string;
  pasajeroId: string;
  pasajero: User;
  estado: "pendiente" | "aceptada" | "rechazada";
  fecha: string;
}

/** Valoración 1-5 estrellas con comentario opcional (sistema de confianza MVP, in-memory). */
export interface Rating {
  id: string;
  deUsuarioId: string;
  paraUsuarioId: string;
  viajeId: string;
  estrellas: number; // 1-5
  comentario?: string;
  fecha: string;
  /** Solo para mostrar en UI en demo (evita lookup de usuario). */
  deUsuarioNombre?: string;
}

export interface ChatMessage {
  id: string;
  emisorId: string;
  receptorId: string;
  mensaje: string;
  fecha: string;
  leido: boolean;
}

/** Chat is ride-scoped; in chat UI never display usuario.correo or phone numbers. */
export interface ChatConversation {
  id: string;
  usuario: User;
  ultimoMensaje: string;
  fecha: string;
  noLeidos: number;
}

export type ReportMotivo =
  | "no_se_presento"
  | "comportamiento_inapropiado"
  | "informacion_falsa"
  | "spam";

export interface Report {
  id: string;
  reportadoPorId: string;
  reportadoId: string;
  motivo: ReportMotivo;
  descripcion?: string;
  fecha: string;
  /** Optional context: trip id when reported from ride detail */
  viajeId?: string;
  /** Optional context: conversation id when reported from chat */
  conversacionId?: string;
}
