# UniCar — Realtime Readiness & Supabase Migration Plan

This document prepares the MVP for a future migration from in-memory demo state to **Supabase** (database + Realtime + Auth). **No Supabase code is implemented yet**; the app continues to work with demo data.

---

## 1. State that will come from Supabase

| Current source | Entity | Future Supabase source |
|----------------|--------|------------------------|
| `demoData.ts` + `AppState` | **trips** (rides) | `rides` table + Realtime |
| `demoData.ts` + `AppState` | **tripRequests** | `trip_requests` table + Realtime |
| `demoData.ts` + `AppState` | **conversations** | Derived from `conversations` + `users` or channel list |
| `AppState` (messages) | **messages** | `messages` table + Realtime (or Supabase Realtime channels) |
| `demoData.ts` | **currentUser** | `auth.users` + `profiles` (or public.profiles) |
| `demoData.ts` (via trips) | **users** (conductors, etc.) | `profiles` table, joined on `rides.conductor_id` |
| `AppState` | **reports** | `reports` table |
| `ratingsStore.ts` | **ratings** | `ratings` table |

**Summary:** All mutable and shared state (rides, trip_requests, messages, conversations, reports, ratings) and the current user should eventually be read/written via Supabase. Static demo seed can be removed once backend is live.

---

## 2. Minimal database tables

- **profiles** — User profile (id from auth.users, nombre, correo, avatar, carrera, curso, email_verified, rating, num_viajes, puntualidad, cancelaciones, valoraciones). Extends or mirrors auth.
- **rides** — One row per ride (or recurring slot). See recommended structure below.
- **trip_requests** — One row per request (passenger + ride). See recommended structure below.
- **conversations** — One row per conversation (e.g. between two users); can include `last_message_at`, `last_message_preview`.
- **messages** — One row per chat message (conversation_id, sender_id, body, created_at, read_at).
- **reports** — One row per report (reporter_id, reported_id, motivo, descripcion, viaje_id, conversacion_id, created_at).
- **ratings** — One row per rating (from_user_id, to_user_id, ride_id, stars, comment, created_at).

Auth is handled by Supabase Auth (`auth.users`); app uses `profiles` for display and trust fields.

---

## 3. Recommended table structure: `rides`

Designed to support the current `Trip` type and Realtime subscriptions (e.g. `plazas_libres` changes when a request is accepted).

```sql
-- rides (main table for "Trip" in the app)
CREATE TABLE rides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conductor_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  origen TEXT NOT NULL,
  destino TEXT NOT NULL,
  hora_salida TIME NOT NULL,           -- or TEXT for "08:00" if no time type
  fecha DATE NOT NULL,
  plazas_total INT NOT NULL CHECK (plazas_total > 0),
  plazas_libres INT NOT NULL CHECK (plazas_libres >= 0 AND plazas_libres <= plazas_total),
  recurrente BOOLEAN NOT NULL DEFAULT false,
  dias_recurrencia TEXT[] DEFAULT NULL, -- e.g. ['L','M','X','J','V']
  notas TEXT,
  estado TEXT NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo','completado','cancelado')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Optional: RLS and Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE rides;
```

**Mapping from current `Trip`:**
- `id` → `rides.id`
- `conductorId` → `rides.conductor_id` (join `profiles` for `conductor` object)
- `origen`, `destino`, `horaSalida`, `fecha`, `plazasTotal`, `plazasLibres`, `recurrente`, `diasRecurrencia`, `notas`, `estado` map 1:1 (snake_case in DB).

---

## 4. Recommended table structure: `trip_requests`

Supports passenger requests and status updates; Realtime can broadcast new/updated requests to drivers.

```sql
-- trip_requests (solicitudes de plaza)
CREATE TABLE trip_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_id UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
  pasajero_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  estado TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','aceptada','rechazada')),
  fecha_solicitud DATE NOT NULL DEFAULT (CURRENT_DATE),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(ride_id, pasajero_id)
);

-- Optional: RLS and Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE trip_requests;
```

**Mapping from current `TripRequest`:**
- `id` → `trip_requests.id`
- `viajeId` → `trip_requests.ride_id`
- `pasajeroId` → `trip_requests.pasajero_id` (join `profiles` for `pasajero` object)
- `estado` → `trip_requests.estado`
- `fecha` → `trip_requests.fecha_solicitud` (or keep as `fecha` in DB)

When a request is accepted, the app (or a DB trigger) should decrement `rides.plazas_libres` so Realtime can push the update to subscribers.

---

## 4b. Recommended table: `profiles`

Referenced by `rides.conductor_id` and `trip_requests.pasajero_id`. Sync with Supabase Auth via trigger or app logic.

```sql
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL,
  correo TEXT NOT NULL UNIQUE,
  avatar TEXT,
  carrera TEXT,
  curso TEXT,
  email_verificado BOOLEAN NOT NULL DEFAULT false,
  rating NUMERIC(2,1) DEFAULT NULL,
  num_viajes INT NOT NULL DEFAULT 0,
  puntualidad INT NOT NULL DEFAULT 100,
  cancelaciones INT NOT NULL DEFAULT 0,
  valoraciones INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

---

## 5. Main functions to replace by Supabase calls

These are the places in the codebase that perform “data access” or “mutations” and should later call Supabase instead of in-memory state.

| Location | Function / behavior | Future Supabase usage |
|----------|---------------------|------------------------|
| **AppState.tsx** | `getInitialState()` (reads seed data) | Fetch `rides`, `trip_requests`, `conversations`, `messages` (e.g. for current user); or subscribe via Realtime. |
| **AppState.tsx** | `addMessage(conversationId, message)` | `supabase.from('messages').insert(...)` + optionally Realtime broadcast. |
| **AppState.tsx** | `addTrip(trip)` | `supabase.from('rides').insert(...)` (create new ride). |
| **AppState.tsx** | `addTripRequest(viajeId)` | `supabase.from('trip_requests').insert({ ride_id, pasajero_id, estado: 'pendiente' })`; optionally update `rides.plazas_libres` via trigger or app. |
| **AppState.tsx** | `hasRequestForTrip(viajeId)` | `supabase.from('trip_requests').select().eq('ride_id', id).eq('pasajero_id', currentUser.id).maybeSingle()`. |
| **AppState.tsx** | `addReport(...)` | `supabase.from('reports').insert(...)`. |
| **demoData.ts** | All exports (`demoTrips`, `demoRequests`, `currentUser`, etc.) | Replaced by Supabase: `profiles`, `rides`, `trip_requests`, `conversations`, `messages`. |
| **ratingsStore.ts** | `getRatingsForUser(paraUsuarioId)` | `supabase.from('ratings').select().eq('to_user_id', id)`. |
| **ratingsStore.ts** | `getAverageRating(paraUsuarioId)` | Same query + compute in app, or use DB view/function. |
| **ratingsStore.ts** | `getRatingCount(paraUsuarioId)` | Same query + count. |
| **ratingsStore.ts** | `getLatestRatings(paraUsuarioId, limit)` | `supabase.from('ratings').select().eq('to_user_id', id).order('created_at', { ascending: false }).limit(limit)`. |
| **AuthPage** (future) | Login/register | `supabase.auth.signInWithPassword` / `signUp`; load `profiles` for current user. |

---

## 6. Files that will need refactor later

- **`src/state/AppState.tsx`** — Replace seed with Supabase fetch/subscribe; replace `addMessage`, `addTripRequest`, `hasRequestForTrip`, `addReport` with Supabase client calls; keep same `AppStateValue` interface so UI code changes are minimal.
- **`src/data/demoData.ts`** — Remove or keep only for fixtures/seeds; all reads go through AppState or a new data layer (e.g. `src/data/supabase.ts`).
- **`src/data/ratingsStore.ts`** — Replace in-memory array and getters with Supabase queries (or a thin service that uses Supabase).
- **`src/types/unicar.ts`** — Optionally add DB-shaped types (snake_case) and mappers to existing `Trip`, `TripRequest`, etc., for cleaner Supabase responses.
- **`src/pages/AuthPage.tsx`** — Integrate Supabase Auth and set current user in context/state from `auth.getUser()` + `profiles`.
- **`src/pages/CreateRidePage.tsx`** — Uses `addTrip`; no change if the state layer is swapped to Supabase behind same interface.
- **`src/pages/HomePage.tsx`** — No signature change if state comes from context; ensure trips are loaded from Supabase (or Realtime) instead of demo.
- **`src/pages/SearchPage.tsx`** — Same; reads `trips` from context (later from Supabase).
- **`src/pages/MyTripsPage.tsx`** — Same; reads `trips`, `tripRequests`, `conversations` from context (later from Supabase).
- **`src/pages/RideDetailPage.tsx`** — Same; uses `addTripRequest`, `hasRequestForTrip`, `addReport` and ratings; swap to Supabase behind the same interface.
- **`src/pages/ChatListPage.tsx`** — Reads `conversations` from context (later from Supabase).
- **`src/pages/ChatConversationPage.tsx`** — Uses `messages`, `addMessage`, `addReport`; later from Supabase + Realtime.
- **`src/pages/ProfilePage.tsx`** — Uses `currentUser` and ratings; later from Supabase.
- **`src/components/RideCard.tsx`** — Uses `getAverageRating`, `getRatingCount`; later from Supabase or from trip/conductor data already loaded with ratings.

Optional new files:
- **`src/lib/supabase.ts`** — Supabase client and helpers.
- **`src/data/rides.ts`** — `fetchRides()`, `subscribeRides()` (Realtime).
- **`src/data/tripRequests.ts`** — `createTripRequest()`, `hasRequestForTrip()`, `subscribeTripRequests()`.
- **`src/data/messages.ts`** — `fetchMessages(conversationId)`, `sendMessage()`, `subscribeMessages(conversationId)`.

---

## 7. Migration steps (high level)

1. **Add Supabase project** — Do not change app behavior yet.
2. **Create tables** — `profiles`, `rides`, `trip_requests`, `conversations`, `messages`, `reports`, `ratings` with the structures above.
3. **Introduce data layer** — e.g. `src/data/supabase.ts` and optional `rides.ts`, `tripRequests.ts`, etc., with the same logical API as current in-memory functions.
4. **Switch AppState** — In `AppState.tsx`, replace `getInitialState()` with loading from Supabase (and optionally Realtime); replace mutators with calls to the new data layer. Keep `AppStateValue` unchanged.
5. **Switch ratings** — Replace `ratingsStore` implementation with Supabase queries; keep the same exported functions if possible.
6. **Wire Auth** — AuthPage uses Supabase Auth; set `currentUser` from `profiles` after login.
7. **Enable Realtime** — Subscribe to `rides` and `trip_requests` (and optionally `messages`) so the UI updates live.
8. **Remove or gate demo data** — Remove `demoData` from the app flow once Supabase is the single source of truth.

This keeps the current MVP intact and limits refactors to the files listed above, with a clear mapping from current state and functions to Supabase tables and client calls.
