# UniCar MVP — State Integrity & Data Consistency Report

**Agent:** State Integrity and Data Consistency Agent  
**Scope:** In-memory app state across the MVP  
**Mode:** Exhaustive debug / consistency audit  

---

## 1. Consistency issues found

### 1.1 Trip request status could not be updated (FIXED)
- **Issue:** App state had no way to accept or reject a trip request. `tripRequests[].estado` was only set on creation (`"pendiente"`) and never updated to `"aceptada"` or `"rechazada"`.
- **Impact:** My Trips “Solicitudes recibidas” showed static data; drivers could not change request status; accepted requests were not reflected in UI.
- **Fix:** Added `updateTripRequestStatus(requestId, 'aceptada' | 'rechazada')` in `AppState`. When status is set to `"aceptada"`, the corresponding trip’s `plazasLibres` is decremented so trips and requests stay in sync.

### 1.2 Trip seats and request status out of sync (FIXED)
- **Issue:** Accepting a request did not reduce `trip.plazasLibres`. Listings could show free seats even when all were taken by accepted requests.
- **Impact:** Search/Home could show trips with 0 real seats; RideDetail could show “X plazas” incorrectly.
- **Fix:** `updateTripRequestStatus(..., 'aceptada')` now updates the trip’s `plazasLibres` (decrement by 1, clamped to 0) in the same state update.

### 1.3 Conversation list stale after sending messages (FIXED)
- **Issue:** `addMessage` only updated `messages[conversationId]`. It did not update `conversations[].ultimoMensaje`, `fecha`, or `noLeidos`.
- **Impact:** Chat list showed old last message and time; unread count did not increase when the current user received a message.
- **Fix:** `addMessage` now also updates the matching conversation: `ultimoMensaje`, `fecha`, and when `message.receptorId === currentUser.id` it increments `noLeidos`.

### 1.4 No conversation when requesting a new trip (FIXED)
- **Issue:** Requesting a trip from a driver with no existing conversation did not create one. “Mensaje” on RideDetail could navigate to `/chat` with no thread for that driver.
- **Impact:** After requesting a ride from a driver without a prior chat, the Message button did not open a conversation.
- **Fix:** `addTripRequest` now ensures a conversation exists with the trip’s driver. If none exists (and the driver is not the current user), it creates and adds a new `ChatConversation` with that driver so the Message button always has a target.

### 1.5 Search/Home showing full or inactive trips (FIXED)
- **Issue:** Search and Home listed all trips from state, including `estado !== 'activo'` and `plazasLibres === 0`.
- **Impact:** Users could see trips with no seats or inactive trips as if they were bookable.
- **Fix:** Search filters to `estado === 'activo' && plazasLibres >= 1`. Home uses `activeTripsWithSeats` (same conditions) for “Cerca de ti” and “Rutas que encajan”.

### 1.6 No UI to accept/reject received requests (FIXED)
- **Issue:** My Trips “Solicitudes recibidas” had no actions; drivers could not accept or reject.
- **Impact:** Request status could not be changed from the app.
- **Fix:** “Solicitudes recibidas” cards with `estado === 'pendiente'` now show “Aceptar” and “Rechazar” buttons that call `updateTripRequestStatus(req.id, 'aceptada' | 'rechazada')`. Clicks use `stopPropagation` so the card’s navigation still works when not clicking the buttons.

---

## 2. Fixes applied (summary)

| Area | Change |
|------|--------|
| **AppState** | `updateTripRequestStatus(requestId, estado)` — updates request and, when `estado === 'aceptada'`, decrements `trip.plazasLibres`. |
| **AppState** | `addMessage` — also updates conversation `ultimoMensaje`, `fecha`, and `noLeidos` when the current user is the receiver. |
| **AppState** | `addTripRequest` — ensures a conversation with the driver exists; creates one if missing (and driver ≠ current user). |
| **AppState** | `addConversation(conversation)` — public API to add a conversation (deduplicated by `usuario.id`). |
| **AppState** | `markConversationAsRead(conversationId)` — sets that conversation’s `noLeidos` to 0. |
| **ChatConversationPage** | On mount, calls `markConversationAsRead(id)` so the unread count clears when opening a thread. |
| **SearchPage** | Filter: only `estado === 'activo'` and `plazasLibres >= 1`. |
| **HomePage** | Uses `activeTripsWithSeats` (same filter) for “Cerca de ti” and “Rutas que encajan”. |
| **MyTripsPage** | Accept/Reject buttons on received requests with `estado === 'pendiente'`. |

---

## 3. Single source of truth & no duplicated logic

- **Trips:** Only `AppState.trips`; created via `addTrip` (CreateRidePage). Home, Search, My Trips, RideDetail all read from `useAppState().trips`. No local trip lists.
- **Trip requests:** Only `AppState.tripRequests`; added via `addTripRequest`, updated via `updateTripRequestStatus`. My Trips and RideDetail use these only.
- **Current user:** Only `AppState.currentUser` (seeded from `demoData.currentUser`). Auth always sets session to `"u0"` (same user), so no mismatch.
- **Conversations / messages:** Only `AppState.conversations` and `AppState.messages`; updated via `addMessage` and (for new convs) inside `addTripRequest` and `addConversation`.
- **RideDetail “no seats”:** Uses `noSeatsLeft = trip.plazasLibres <= 0` and disables “Solicitar plaza” when true; consistent with filtered lists.

---

## 4. Remaining weak areas & recommendations

### 4.1 Current user vs auth (low risk in current demo)
- **State:** `currentUser` is fixed from `demoData`; auth always sets session to `"u0"`.
- **Risk:** If later you support multiple users, session could point to another user while `currentUser` stays the seed user.
- **Recommendation:** When moving to real auth, set `currentUser` from the authenticated user (or a profile fetch) and keep a single source (e.g. context or store derived from session).

### 4.2 Conversation `noLeidos` (addressed)
- **State:** `noLeidos` is incremented when the current user receives a message.
- **Fix applied:** Added `markConversationAsRead(conversationId)` in AppState; ChatConversationPage calls it in a `useEffect` when the conversation is opened, so the unread badge clears.

### 4.3 Created rides and conversations
- **State:** When the current user creates a ride, no conversation is created for “chat with passengers”. That’s acceptable for MVP (driver doesn’t need a self-conversation). When a passenger requests that ride, `addTripRequest` creates a conversation with the driver (current user), so the passenger can message.
- **Weakness:** Conversations are created per driver–passenger pair, not per ride. Multiple requests on the same ride still share one conversation. Acceptable for demo; for production you may want ride-scoped or request-scoped threads.

### 4.4 Refresh / persistence
- **State:** All state is in memory; refresh loses new trips, requests, and messages.
- **Recommendation:** Document as demo behavior; for production, replace with Supabase (or similar) as in the migration plan and keep the same single-source patterns (one store/context, no duplicated lists).

### 4.5 Ratings and reports
- **State:** `ratingsStore` is separate from AppState; reports are in AppState but not displayed in a dedicated UI. No inconsistency found for MVP.
- **Recommendation:** When adding “Mis valoraciones” or report lists, read from `AppState.reports` and from `ratingsStore` (or future API) as the single source.

### 4.6 Home “Live stats” bar
- **State:** “Viajes hoy”, “Compartiendo”, “Plazas libres” are hardcoded (`"12"`, `"8"`, `"23"`).
- **Impact:** Stats do not reflect real state.
- **Recommendation:** Derive from `trips` (e.g. by date, by `conductorId === currentUser.id`, and sum of `plazasLibres`) when you want them to be consistent with the rest of the app.

---

## 5. Stable data behavior across refresh-safe demo flows

- **Create ride → Home / Search / My Trips:** New trip is in `trips`; Home and Search show it (if active and with seats); My Trips shows it under “Próximos viajes” for the driver. No duplicate or stale lists.
- **Request seat → RideDetail / My Trips:** Request is in `tripRequests`; RideDetail shows “Solicitud enviada”; My Trips shows it under “Solicitudes enviadas”; conversation is created so “Mensaje” works.
- **Accept/Reject (driver):** Request status and trip seats update in one step; My Trips and RideDetail see updated state; Search/Home no longer show the trip if it becomes full (filter).
- **Send message:** Message is in `messages`; conversation’s last message and unread count update so the chat list stays correct.

---

## 6. Files touched

- `src/state/AppState.tsx` — `updateTripRequestStatus`, `addConversation`, `markConversationAsRead`, `addMessage` (conv update), `addTripRequest` (ensure conversation).
- `src/pages/ChatConversationPage.tsx` — `markConversationAsRead(id)` in `useEffect` on open.
- `src/pages/MyTripsPage.tsx` — `updateTripRequestStatus` usage; Accept/Reject on received requests.
- `src/pages/SearchPage.tsx` — filter by `estado` and `plazasLibres`.
- `src/pages/HomePage.tsx` — `activeTripsWithSeats` for both sections.
- `docs/STATE_CONSISTENCY_REPORT.md` — this report.

No changes to RideDetailPage for consistency (it already used `noSeatsLeft` and correct state).
