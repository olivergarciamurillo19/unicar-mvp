# UniCar MVP Scope — v1

**Goal:** One flow that works end-to-end with no broken steps and no fake behavior.

**Single main user flow (must work perfectly):**
> User logs in → sees rides → opens a ride → requests a seat → sees request status.

---

## 1. Features IN scope for v1

| Feature | What to implement | Notes |
|--------|--------------------|--------|
| **Login** | Supabase Auth (email + password). One route: `/auth`. After login → redirect to `/home`. | Reuse existing `AuthPage`; wire to `supabase.auth.signInWithPassword` / `signUp`. No magic link, no social, no "forgot password" in v1. |
| **Session / protected routes** | If no session → redirect to `/auth`. Apply to `/home`, `/search`, `/ride/:id`, `/trips`. | Use `supabase.auth.getSession()` and a small auth context or route guard. |
| **List rides** | Load rides from Supabase (one table `trips`). Show on Home and Search. | Replace `demoTrips` with real query. Keep existing `RideCard` and list UIs. |
| **Ride detail** | Load one trip by id from DB. Show same info as now (origin, destination, time, driver, seats). | Replace `demoTrips.find(id)` with `supabase.from('trips').select().eq('id', id).single()`. |
| **Request seat** | Create a row in `trip_requests` (trip id, passenger = current user id, status = `pendiente`). | Replace toast with `supabase.from('trip_requests').insert(...)`. Disable button if user already has a request for this trip. |
| **See request status** | On Ride detail: show "Pending" / "Accepted" / "Rejected" if current user has a request. In "My trips": list user's requests with same statuses. | Use `trip_requests` filtered by current user; join or fetch trip info for display. Reuse existing status badges from `MyTripsPage`. |

**Data model (minimal for v1):**

- **profiles** (or use Supabase auth metadata): `id` (auth.uid), `nombre`, `correo` (optional: `carrera`, `curso` for display).
- **trips**: `id`, `conductor_id` (FK to profiles), `origen`, `destino`, `hora_salida`, `fecha`, `plazas_total`, `plazas_libres`, `estado` (`activo`/`completado`/`cancelado`), optional `notas`. No recurrence in v1.
- **trip_requests**: `id`, `trip_id`, `passenger_id`, `estado` (`pendiente`|`aceptada`|`rechazada`), `created_at`.

**Flows to keep working (no regressions):**

- `/` or unauthenticated → redirect to `/auth`.
- `/auth` → submit → login/signup → redirect `/home`.
- `/home` and `/search` → show real trips from DB.
- `/ride/:id` → real trip from DB; "Solicitar plaza" creates real request; if user already requested, show status (Pendiente/Aceptada/Rechazada) instead of button.
- `/trips` → "Solicitudes enviadas" from DB for current user (with status); clicking a request can go to `/ride/:id` for that trip.

---

## 2. Features OUT of scope for v1

| Feature | Why excluded |
|--------|---------------|
| **Onboarding** | Not required for "login → see rides → request → see status". Keep as optional post-login screen or remove from critical path; do not block v1. |
| **Create ride (publish trip)** | Doubles scope (driver flow). v1 = passenger flow only; drivers can be seeded or created via backend. |
| **Chat** | Adds realtime/messages and complexity. v1 = no in-app chat. |
| **Profile edit** | View only is enough (e.g. show name/email from auth). No edit form in v1. |
| **Driver: accept/reject request** | Can be v1.1. For v1, requests can stay "pendiente" or you add a minimal driver view: list requests for my trips, accept/reject with one click. Only include if it doesn’t delay the main flow. |
| **Recurring trips** | Demo has `recurrente` / `diasRecurrencia`. v1 = single-date trips only. |
| **Map on home** | `HomeMap` is nice-to-have. v1 can show a static or simplified map, or a placeholder, to avoid map API/key issues. |
| **Environmental stats** | "156 coches reducidos", etc. are fake. Remove or replace with "Coming soon" so the app doesn’t promise unimplemented features. |
| **Notifications** | No push/email in v1. |
| **Ratings, reports, share** | All out of v1. |

**Navigation:**

- Keep bottom nav: Home, Search, Trips, (optionally Create as disabled "Próximamente"), Profile. Remove or hide Chat for v1 so no one hits a broken flow.

---

## 3. Single main user flow (implementation checklist)

Use this as the acceptance criteria for v1.

1. **User logs in**
   - [ ] `/auth` in routes; unauthenticated users hitting `/home` (or `/`) go to `/auth`.
   - [ ] Auth form calls Supabase; on success redirect to `/home`.
   - [ ] Session persisted (Supabase client already uses `localStorage`).

2. **Sees rides**
   - [ ] `/home` and `/search` load trips from Supabase (no `demoTrips`).
   - [ ] Empty state if no trips (no crash, no fake list).

3. **Opens a ride**
   - [ ] `/ride/:id` loads trip from DB by id; 404 or back if not found.
   - [ ] Same detail UI (driver, origin, destination, time, seats).

4. **Requests a seat**
   - [ ] "Solicitar plaza" creates a row in `trip_requests` (trip_id, user id, `pendiente`).
   - [ ] No duplicate requests (disable or hide button if request already exists).
   - [ ] Toast or inline message: "Solicitud enviada".

5. **Sees request status**
   - [ ] On `/ride/:id`: if current user has a request for this trip, show "Pendiente" / "Aceptada" / "Rechazada" instead of "Solicitar plaza".
   - [ ] On `/trips`: section "Solicitudes enviadas" lists requests for current user with correct status; each links to the corresponding ride.

**Definition of done for v1:** The five steps above work with real Supabase auth and database; no demo data in that path; no broken links or dead buttons in that flow.

---

## 4. Suggested implementation order

1. **Supabase**
   - Create tables: `profiles` (sync with auth), `trips`, `trip_requests`. RLS so users can read trips, insert/read their own requests.
2. **Auth**
   - Add `/auth` route; protect `/home`, `/search`, `/ride/:id`, `/trips`; redirect unauthenticated to `/auth`; wire `AuthPage` to Supabase.
3. **Rides**
   - Replace demo with Supabase: fetch trips on Home and Search; fetch one trip on Ride detail.
4. **Request seat**
   - Insert `trip_requests` from Ride detail; prevent duplicates; show success feedback.
5. **Request status**
   - On Ride detail: query user’s request for this trip and show status.
   - On Trips: query user’s requests with trip data and show "Solicitudes enviadas" from DB.
6. **Cleanup**
   - Remove or stub Chat/Create in nav for v1; simplify or remove fake stats; ensure no remaining `demoTrips`/`demoRequests` in the main flow.

---

## 5. What to remove or simplify for v1

- **HomePage:** Remove or replace "Impacto ambiental" and "Viajes hoy / Conductores / Plazas" with static text or "—" so the app doesn’t imply real metrics.
- **RideDetailPage:** Remove "Mensaje" and "Compartir" if Chat is out; or keep as disabled "Próximamente". Remove "Reportar incidencia" for v1.
- **BottomNav:** Remove "Publicar" or make it open a "Próximamente" message; remove or hide "Mensajes" (Chat).
- **Data:** No imports of `demoTrips` / `demoRequests` / `currentUser` in the main flow; replace with Supabase + auth user.

This keeps v1 small, reliable, and focused on one flow that works perfectly.
