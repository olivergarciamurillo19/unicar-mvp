# UniCar – Authentication & Session Debug Report

**Date:** 2025-03-13  
**Scope:** Demo auth flow, session persistence, redirects, protected routes, onboarding, edge cases.

---

## 1. Issues found and fixed

### 1.1 Login flow

| Issue | Fix |
|-------|-----|
| **Authenticated user could see login form** – Visiting `/auth` while already logged in (e.g. back button or direct URL) showed the login form. | **Redirect at render:** If `isAuthenticated()` is true, `AuthPage` now returns `<Navigate to="/home" replace />` immediately, so the login form is never shown. |
| **Weak validation** – Only `includes("@")` for email; password/name not trimmed. | **Validation:** Added `looksLikeEmail()` (format with @ and domain). Email, password and name are trimmed; password must be ≥6 chars, name (register) ≥2 chars. |
| **No double-submit guard** | **Guard:** `isSubmitting` state blocks duplicate submit; button shows "Espera..." and is disabled while submitting. |
| **Post-login redirect ignored “return URL”** – After login from a protected route, user always went to onboarding. | **Return URL:** `ProtectedRoute` now passes `state: { from: location.pathname }` to `/auth`. On successful login, if `from` is a valid app path, user is sent to `from`; otherwise to `/onboarding`. |

### 1.2 Logout flow

| Issue | Fix |
|-------|-----|
| **None** – Logout already called `clearSession()`, showed toast, and `navigate("/auth", { replace: true })`. | No code change. Confirmed flow is correct. |

### 1.3 Local session persistence

| Issue | Fix |
|-------|-----|
| **localStorage could throw** (e.g. private mode, quota). | **demoAuth:** All `getSession` / `setSession` / `clearSession` calls are wrapped in try/catch; failures are ignored or return `null` so the app does not crash. |
| **Empty/whitespace session** – Stored value was not normalized. | **getSession:** Returns `null` when stored value is empty or only whitespace (already trimmed). **setSession:** Trims and ignores empty `userId`. |

### 1.4 Redirects after login

| Issue | Fix |
|-------|-----|
| **Always to `/onboarding`** | **Return URL:** After login, redirect is `from` (if valid protected path) or `/onboarding`. Valid paths: `/home`, `/search`, `/create`, `/trips`, `/profile`, `/chat`, `/ride/*`. |
| **Replace history** | Login and onboarding “finish” actions use `navigate(..., { replace: true })` to avoid stacking history. |

### 1.5 Redirects when not authenticated

| Issue | Fix |
|-------|-----|
| **Protected routes** | **ProtectedRoute** already redirected to `/auth` with `replace`. Now also passes `state.from` for return-after-login. |
| **Onboarding without session** – useEffect redirect caused a short flash of onboarding content. | **OnboardingPage:** If `!isAuthenticated()`, returns `<Navigate to="/auth" replace />` at render so no flash. |
| **Root `/`** | **RootRedirect** unchanged: authenticated → `/home`, otherwise → `/auth`. |

### 1.6 Protected routes

| Issue | Fix |
|-------|-----|
| **No return URL** | **ProtectedRoute** now does `<Navigate to="/auth" state={{ from: location.pathname }} replace />` so login can send the user back. |
| **Direct access** | Unauthenticated direct access to `/home`, `/profile`, etc. still redirects to `/auth`; behavior confirmed. |

### 1.7 Onboarding / auth / home flow

| Issue | Fix |
|-------|-----|
| **Redundant `setSession` in onboarding** – `goHome()` called `setSession("u0")` even though session was already set at login. | **OnboardingPage:** Removed `setSession` from `goHome()`; it only calls `navigate("/", { replace: true })`. |
| **Onboarding visible when not logged in** | See “Redirects when not authenticated” above: render-time redirect to `/auth`. |

### 1.8 Edge cases and messages

| Edge case | Handling |
|-----------|----------|
| **Invalid email** (no @, bad format) | “El correo no tiene un formato válido (debe contener @ y dominio)”. |
| **Non-UAL email** | “Solo puedes entrar con tu correo @ual.es de la universidad” / “Usa tu correo @ual.es para unirte a la comunidad universitaria”. |
| **Empty fields** | Separate messages: “Introduce tu correo electrónico”, “Introduce tu contraseña”, “Introduce tu nombre completo”. |
| **Password too short** | “La contraseña debe tener al menos 6 caracteres”. |
| **Name too short (register)** | “El nombre debe tener al menos 2 caracteres”. |
| **Direct access to protected route** | Redirect to `/auth` with `state.from`; after login, redirect to `from`. |
| **Page refresh with existing session** | Session in `localStorage` (`unicar_demo_session`); `getSession()` / `isAuthenticated()` still true; protected routes and RootRedirect behave correctly. |
| **Logout and re-entry** | Logout clears session and goes to `/auth`; user can log in again and is sent to `/onboarding` or `from` as above. |

All user-facing error messages are in Spanish.

---

## 2. Files changed

- **`src/lib/demoAuth.ts`** – Try/catch in get/set/clear; trim and empty checks; JSDoc.
- **`src/pages/AuthPage.tsx`** – Redirect when authenticated; `useLocation` and return URL; `looksLikeEmail`; trimmed validation; min length; `isSubmitting`; Spanish messages.
- **`src/pages/OnboardingPage.tsx`** – Render-time redirect when unauthenticated; removed redundant `setSession` in `goHome()`.
- **`src/components/ProtectedRoute.tsx`** – Pass `state: { from: location.pathname }` when redirecting to `/auth`.

---

## 3. Behaviour summary

- **Login:** Validate email (format + @ual.es), password (trim, min 6), name on register (trim, min 2). Redirect to `from` if valid, else `/onboarding`. If already authenticated, redirect to `/home` without showing the form.
- **Logout:** Clear session, toast, navigate to `/auth` with replace.
- **Session:** Stored in `localStorage` under `unicar_demo_session`; reads/writes guarded for SSR and localStorage errors.
- **Protected routes:** No session → redirect to `/auth` with `state.from`; after login, redirect to `from` when valid.
- **Onboarding:** Allowed only when authenticated; otherwise redirect to `/auth`. “Empezar” goes to `/` → RootRedirect → `/home`.

---

## 4. Remaining risks

1. **Demo-only auth** – Session is a string in `localStorage`; no JWT, no server check. Replace with real auth (e.g. Supabase) before production.
2. **AppState vs session** – `AppStateProvider` still uses seed user; it does not sync with demo auth. For demo this is fine; for production, user data should come from the auth/session layer.
3. **Return URL validation** – Only path pattern is checked; no server-side check. Acceptable for demo; with real auth, validate or sanitize `from` on the server.
4. **No “session expired”** – Demo session does not expire. With real auth, add expiry and redirect to login with a clear message when expired.
5. **404 “Volver al inicio”** – Links to `/`; RootRedirect then sends to `/home` or `/auth`. No change needed; just note that deep links to invalid routes always land on `/` first.

---

## 5. How to test manually

1. **Invalid email** – Submit with `foo`, `foo@`, `@bar.com` → expect Spanish error.
2. **Non-UAL email** – Submit with `user@gmail.com` → expect “Solo puedes entrar con tu correo @ual.es”.
3. **Empty fields** – Submit with empty email/password/name → expect “Introduce tu…” messages.
4. **Direct protected route** – Log out, open `/home` or `/profile` → redirect to `/auth`; after login, redirect back to that page.
5. **Already logged in** – With session, open `/auth` → redirect to `/home` (no login form).
6. **Onboarding without session** – Clear `localStorage` and open `/onboarding` → redirect to `/auth`.
7. **Refresh with session** – Log in, refresh on `/home` → stay on `/home`.
8. **Logout and re-entry** – Log out from profile → `/auth`; log in again → onboarding or return URL.

**Debug tip:** In DevTools → Application → Local Storage, inspect `unicar_demo_session`. Remove it to simulate logged-out state.
